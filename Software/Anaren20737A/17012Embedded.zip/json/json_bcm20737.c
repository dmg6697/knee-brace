#include <stdint.h>
#include "json.h"
#include "string.h"
#include "stdio.h"
#include "spar_utils.h"
#include "../fp_math/fp_math.h"

#define INFINITY (__builtin_inff())
#define NAN (__builtin_nanf(""))

static char jsonRetBuffer[JSON_RET_BUFFER_SIZE];
static int jsonError = 0;

void JSON_Init()
{
	jsonError = JSON_NO_ERROR;
}

int JSON_GetError()
{
	return jsonError;
}

char JSON_ReadChar(char *jsonString)
{
	jsonString = JSON_ReadString(jsonString);
	unsigned int i = 0;
	
	for(; jsonString[i] != '\0'; i++)
	{
		if(jsonString[i] != '"')
		{
			return jsonString[i];
		}
	}
	
	return jsonString[0];
}

int JSON_ReadInt(char *jsonString)
{
	unsigned int i = 0;
	bool negative = false;
	int value = 0;
	bool foundSign = false;
	bool foundNumberStart = false;
	
	jsonString = JSON_ReadString(jsonString);
	
	for (; jsonString[i] != '\0'; i++)
	{
		if (jsonString[i] >= '0' && jsonString[i] <= '9')
		{
			foundNumberStart = true;
			value = value * 10;
			value = value + (jsonString[i] - '0');
		}

		else if (jsonString[i] == '-')
		{
			if (!foundNumberStart && !foundSign)
			{
				negative = true;
				foundSign = true;
			}

			else
			{
				goto parse_failed;
			}
		}
		
		else if (jsonString[i] == '+')
		{
			if (!foundNumberStart && !foundSign)
			{
				negative = false;
				foundSign = true;
			}

			else
			{
				goto parse_failed;
			}
		}
		
		else if (jsonString[i] == '.')
		{
			if (negative)
			{
				return value * -1;
			}

			else
			{
				return value;
			}
		}
		
		else
		{
			goto parse_failed;
		}
	}

	jsonError = JSON_NO_ERROR;

	if (negative)
	{
		return value * -1;
	}

	else
	{
		return value;
	}

parse_failed:
	jsonError = JSON_PARSING_ERROR;
	return 0;
}

float JSON_ReadFloat(char *data)
{
	unsigned int i = 0;
	bool negative = false;
	bool tokenDecimal = false;
	bool foundSign = false;
	bool foundNumberStart = false;
	float value = 0.0f;
	float m = 0.1f;
	
	data = JSON_ReadString(data);
	
	for (; data[i] != '\0'; i++)
	{
		if (data[i] >= '0' && data[i] <= '9')
		{
			foundNumberStart = true;
			
			if (!tokenDecimal)
			{
				value = value * 10.0f;
				value = value + (float)(data[i] - '0');
			}

			else
			{
				value = value + ((float)(data[i] - '0') * m);
				m = m * 0.1;
			}
		}

		else if (data[i] == '-')
		{
			if (!foundNumberStart && !foundSign)
			{
				negative = true;
				foundSign = true;
			}

			else
			{
				goto parse_failed;
			}
		}
		
		else if (data[i] == '+')
		{
			if (!foundNumberStart && !foundSign)
			{
				negative = false;
				foundSign = true;
			}

			else
			{
				goto parse_failed;
			}
		}

		else if (data[i] == '.')
		{
			if (tokenDecimal)
			{
				goto parse_failed;
			}

			else
			{
				tokenDecimal = true;
			}
		}
		
		else
		{
			goto parse_failed;
		}
	}

	if (negative)
	{
		if(value == 0.0f)
			return -0.0f;
		
		else 
			return value * -1.0f;
		
		
	}

	else
	{
		return value;
	}

parse_failed:
	if(strcmp(data, "Infinity") == 0)
		return INFINITY;
	
	else if(strcmp(data, "-Infinity") == 0)
		return -INFINITY;
	
	else if(strcmp(data, "NaN") == 0)
		return NAN;

	return 0.0f;
}

char *JSON_ReadString(char *jsonString)
{
	unsigned int i = 0;
	unsigned int j = 0;

	bool tokenStarted = false;
	bool tokenEnded = false;

	for (; j < JSON_RET_BUFFER_SIZE && !tokenEnded; i++)
	{
		switch (jsonString[i])
		{
		case '\0':
			goto parse_failed;
			break;

		case '"':
			if (!tokenStarted)
			{
				tokenStarted = true;
			}

			else
			{
				tokenEnded = true;
			}

			break;

		case '\\':
		{
			if (!tokenStarted)
				goto parse_failed;

			switch (jsonString[++i])
			{
			case '"':
				jsonRetBuffer[j] = '"';
				j++;
				break;

			case '/':
				jsonRetBuffer[j] = '/';
				j++;
				break;

			case 'b':
				jsonRetBuffer[j] = '\b';
				j++;
				break;

			case 'f':
				jsonRetBuffer[j] = '\f';
				j++;
				break;

			case 'n':
				jsonRetBuffer[j] = '\n';
				j++;
				break;

			case 'r':
				jsonRetBuffer[j] = '\r';
				j++;
				break;

			case 't':
				jsonRetBuffer[j] = '\t';
				j++;
				break;

			case '\\':
				jsonRetBuffer[j] = '\\';
				j++;
				break;

			default:
				goto parse_failed;
				break;
			}

			break;
		}

		default:
			if (!tokenStarted)
				goto parse_failed;

			jsonRetBuffer[j] = jsonString[i];
			j++;
			break;
		}
	}

	if (j < JSON_RET_BUFFER_SIZE - 1)
	{
		jsonRetBuffer[j] = '\0';
	}

	else
	{
		jsonRetBuffer[JSON_RET_BUFFER_SIZE - 1] = '\0';
		jsonError = JSON_RETURN_TO_LARGE;
		return NULL;
	}

	jsonError = JSON_NO_ERROR;

	return jsonRetBuffer;

parse_failed:
	jsonError = JSON_PARSING_ERROR;
	return jsonString;
}

bool JSON_ReadBoolean(char *jsonString)
{
	
	if(jsonString == NULL)
	{
		return false;
	}
	
#ifdef JSON_QUICK_AND_DIRTY
	jsonError = JSON_NO_ERROR;

	if (strcmp(jsonString, "true") == 0)
	{
		return true;
	}

	else if (strcmp(jsonString, "false") == 0)
	{
		return false;
	}
	
	else if (strcmp(jsonString, "null") == 0)
	{
		return false;
	}
	
	else if (strcmp(jsonString, "\"\"") == 0)
	{
		return false;
	}
	
	else if (strcmp(jsonString, "0") == 0)
	{
		return false;
	}
	
	unsigned int i = 0; 
	unsigned int len = strlen(jsonString);
	
	if(len > 0) {
		return true;
	}
	
	return false;
	
#else
	jsonError = JSON_MISSING_CAPABILITY;

	return false;
#endif
}

char *JSON_WriteInt(int value)
{
	jsonError = JSON_NO_ERROR;

	sprintf(jsonRetBuffer, "%d", value);
	return jsonRetBuffer;
}

void myPrintf(float fVal)
{
    char result[100];
    int dVal, dec, i;

    fVal += 0.005;   // added after a comment from Matt McNabb, see below.

    dVal = fVal;
    dec = (int)(fVal * 100) % 100;

    memset(result, 0, 100);
    result[0] = (dec % 10) + '0';
    result[1] = (dec / 10) + '0';
    result[2] = '.';

    i = 3;
    while (dVal > 0)
    {
        result[i] = (dVal % 10) + '0';
        dVal /= 10;
        i++;
    }

    for (i=strlen(result)-1; i>=0; i--)
        putc(result[i], stdout);
}

char *JSON_WriteFloat(float value)
{
	int magCounter;
	jsonRetBuffer[0] = '\0';
	if(0x80000000 & *((uint32_t*) & value))
	{
		strcat(jsonRetBuffer, "-");
		value = -value;
	}
	if((0x7F800000 & *((uint32_t*) & value)) == 0x7F800000)
	{
		if(0x7FFFFF & *((uint32_t*) & value))
		{
			strcat(jsonRetBuffer, "NaN");
			return jsonRetBuffer;
		}
		strcat(jsonRetBuffer, "Infinity");
		return jsonRetBuffer;
	}
	if(!value)
	{
		strcat(jsonRetBuffer, "0");
		return jsonRetBuffer;
	}
	for(magCounter = 38; value/fp_pow(10, magCounter) < 1 || value/fp_pow(10, magCounter) >= 10; magCounter--){
		if(magCounter == -1){
			strcat(jsonRetBuffer, "0.");
		}
		if(magCounter < 0)
		{
			strcat(jsonRetBuffer, "0");
		}
	}
	if(magCounter == -1){
		strcat(jsonRetBuffer, "0");
	}
	for(; value && strlen(jsonRetBuffer) < JSON_RET_BUFFER_SIZE; magCounter--)
	{
		if(magCounter == -1){
			strcat(jsonRetBuffer, ".");
		}
		switch((int)(value/fp_pow(10, magCounter)))
		{
		case 9:
			strcat(jsonRetBuffer, "9");
			break;
		case 8:
			strcat(jsonRetBuffer, "8");
			break;
		case 7:
			strcat(jsonRetBuffer, "7");
			break;
		case 6:
			strcat(jsonRetBuffer, "6");
			break;
		case 5:
			strcat(jsonRetBuffer, "5");
			break;
		case 4:
			strcat(jsonRetBuffer, "4");
			break;
		case 3:
			strcat(jsonRetBuffer, "3");
			break;
		case 2:
			strcat(jsonRetBuffer, "2");
			break;
		case 1:
			strcat(jsonRetBuffer, "1");
			break;
		default:
			strcat(jsonRetBuffer, "0");
		}
		value -= ((int)(value/fp_pow(10, magCounter))) * fp_pow(10, magCounter);
	}
	while(magCounter-- >= 0){
		strcat(jsonRetBuffer, "0");
	}
	
	return jsonRetBuffer;
}

char *JSON_WriteString(char *string)
{
	unsigned int i = 0;
	unsigned int j = 0;

	jsonRetBuffer[j] = '"';

	j++;

	for (; j < JSON_RET_BUFFER_SIZE - 2; i++)
	{
		switch (string[i])
		{
		case '\0':
			jsonRetBuffer[j] = '"';
			jsonRetBuffer[j + 1] = '\0';
			j = j + 2;

		case '\\':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = '\\';
			j = j + 2;
			break;

		case '\"':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = '\"';
			j = j + 2;
			break;

		case '/':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = '/';
			j = j + 2;
			break;

		case '\b':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = 'b';
			j = j + 2;
			break;

		case '\f':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = 'f';
			j = j + 2;
			break;

		case '\n':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = 'n';
			j = j + 2;
			break;

		case '\r':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = 'r';
			j = j + 2;
			break;

		case '\t':
			jsonRetBuffer[j] = '\\';
			jsonRetBuffer[j + 1] = 't';
			j = j + 2;
			break;

		default:
			jsonRetBuffer[j] = string[i];
			j++;
			break;
		}

		if (string[i] == '\0')
		{
			break;
		}
	}

	jsonError = JSON_NO_ERROR;

	return jsonRetBuffer;
}

char *JSON_WriteBoolean(bool value)
{
	if (value)
	{
		sprintf(jsonRetBuffer, "true");
	}

	else
	{
		sprintf(jsonRetBuffer, "false");
	}

	jsonError = JSON_NO_ERROR;

	return jsonRetBuffer;
}
