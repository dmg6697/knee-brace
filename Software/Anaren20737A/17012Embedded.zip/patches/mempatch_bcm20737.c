#include "bleprofile.h"

void *__wrap_memset(void *v_src, int c, size_t n)
{
	return (void*)__aeabi_memset(v_src, n, c);
}

void *__wrap_memcpy(void *v_dst, const void *v_src, size_t c)
{
	return (void*)__aeabi_memcpy(v_dst, v_src, c);
}
