#include "../json/json.h"

float __wrap_atof(const char* data)
{
	return JSON_ReadFloat((char *)data);
}