#include "bleprofile.h"
#include "bleapp.h"
#include "gatt.h"
#include "../air_gatt_defines.h"

#if defined(ATMOSPHERE_GATT_GAP_DEVICE_NAME_HANDLE)
void AIR_GATT_GAP_SetDeviceName(char *name)
{
	if (name == NULL)
		return;

	BLEPROFILE_DB_PDU* long_db_pdu = cfa_mm_Alloc(sizeof(UINT8) + sizeof(UINT8) + 32);

	unsigned char i;

	for (i = 0; i < 32; i++)
	{
		if (name[i] == 0x00)
		{
			break;
		}

		else
		{
			long_db_pdu->pdu[i] = name[i];
		}
	}

	for (i; i < 32; i++)
	{
		long_db_pdu->pdu[i] = 0x00;
	}

	long_db_pdu->len = 32;

	bleprofile_WriteHandleData(ATMOSPHERE_GATT_GAP_DEVICE_NAME_HANDLE, long_db_pdu, sizeof(UINT8) + sizeof(UINT8) + 32);
	cfa_mm_Free(long_db_pdu);
}

void AIR_GATT_GAP_GetDeviceName(char *buffer, unsigned int length)
{
	BLEPROFILE_DB_PDU* long_db_pdu = cfa_mm_Alloc(sizeof(UINT8) + sizeof(UINT8) + 32);

	bleprofile_ReadHandle(ATMOSPHERE_GATT_GAP_DEVICE_NAME_HANDLE, long_db_pdu);

	unsigned char i = 0;

	for (i; i < long_db_pdu->len && i < length; i++)
	{
		buffer[i] = long_db_pdu->pdu[i];
	}

	cfa_mm_Free(long_db_pdu);

	return;
}
#endif

#if defined(ATMOSPHERE_GATT_BATTERY_HANDLE)
void AIR_GATT_BATTERY_SetLevel(char level)
{
	BLEPROFILE_DB_PDU db_pdu;

	db_pdu.len = 1;
	db_pdu.pdu[0] = level;

	bleprofile_WriteHandle(ATMOSPHERE_GATT_BATTERY_HANDLE, &db_pdu);
}

char AIR_GATT_BATTERY_GetLevel()
{
	BLEPROFILE_DB_PDU db_pdu;

	bleprofile_ReadHandle(ATMOSPHERE_GATT_BATTERY_HANDLE, &db_pdu);

	return db_pdu.pdu[0];
}

void AIR_GATT_BATTERY_SetAndNotifyLevel(char level)
{
	AIR_GATT_BATTERY_SetLevel(level);
	AIR_GATT_BATTERY_NotifyLevel(level);
}

void AIR_GATT_BATTERY_NotifyLevel(char level)
{
	bleprofile_sendNotification(ATMOSPHERE_GATT_BATTERY_HANDLE, (UINT8*)&level, 1);
}

void AIR_GATT_BATTERY_NotifyCurrentLevel()
{
	BLEPROFILE_DB_PDU db_pdu;

	bleprofile_ReadHandle(ATMOSPHERE_GATT_BATTERY_HANDLE, &db_pdu);
	AIR_GATT_BATTERY_NotifyLevel(db_pdu.pdu[0]);
}
#endif

#if defined(ATMOSPHERE_GATT_IMMEDIATE_ALERT_HANDLE)

static air_immediate_alert_callback_func_ptr immediateAlertCallback = NULL;

void AIR_GATT_IMMEDIATE_ALERT_RegisterCallback(air_immediate_alert_callback_func_ptr func)
{
	immediateAlertCallback = func;
}

void AIR_GATT_IMMEDIATE_ALERT_ExecuteCallback(unsigned char data)
{
	AIR_GATT_IMMEDIATE_ALERT_Type alertType = AIR_GATT_IMMEDIATE_ALERT_RESERVED;

	if (data == 0)
	{
		alertType = AIR_GATT_IMMEDIATE_ALERT_NO_ALERT;
	}

	else if (data == 1)
	{
		alertType = AIR_GATT_IMMEDIATE_ALERT_MILD_ALERT;
	}

	else if (data == 2)
	{
		alertType = AIR_GATT_IMMEDIATE_ALERT_HIGH_ALERT;
	}

	if (immediateAlertCallback != NULL)
	{
		immediateAlertCallback(alertType);
	}
}
#endif

#if defined(ATMOSPHERE_GATT_BLOOD_PRESSURE_MEASUREMENT_HANDLE)
#endif