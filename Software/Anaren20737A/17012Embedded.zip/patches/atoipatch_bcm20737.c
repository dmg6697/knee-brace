#include <stdlib.h>

/* Convert a string to an int.  */
int __wrap_atoi (const char *nptr)
{
	return (int) strtol(nptr, (char **) NULL, 10);
} 
