#include "power.h"
#include "bleprofile.h"
#include "bleapp.h"
#include "string.h"
#include "stdio.h"
#include "bleappconfig.h"
#include "cfa.h"
#include "devicelpm.h"
#include "hidddriversconfig.h"
#include "miadriver.h"
#include "gpiodriver.h"
#include "bleappfwu.h"

unsigned int deepsleepTimeInterval = 10000;

void AIR_POWER_enterHidoff(void);
void AIR_POWER_abortHidoff(void);

void AIR_POWER_enterHidoff(void)
{
	// Do nothing
}

void AIR_POWER_abortHidoff(void)
{
	// Do nothing
}

static AIR_POWER_Mode currentSleepMode = AIR_POWER_NOSLEEP;

// This callback function is expected to respond with time to
/// sleep or if it is ok to enter hid off or not. A 0 value indicates
/// do not sleep or do not go hid-off and a non-zero value for sleep is the sleep time
/// or ok to go hid-off
UINT32 air_power_lpm_queriable(LowPowerModePollType type, UINT32 context)
{
	switch (type)
	{
	case LOW_POWER_MODE_POLL_TYPE_SLEEP:
		if (currentSleepMode == AIR_POWER_SLEEP || currentSleepMode == AIR_POWER_OFF)
		{
			return ~0;
		}

		break;

	case LOW_POWER_MODE_POLL_TYPE_POWER_OFF:
		if (currentSleepMode == AIR_POWER_OFF)
		{
			return 1;
		}

		else
		{
			return 0;
		}

		break;
	}

	return 0;
}

void AIR_POWER_Init()
{
	//We woke up from deep sleep... We now need to reset the chip.
	if (!mia_isResetReasonPor())
	{
		gpio_clearPinInterruptStatus(GPIO_PIN_P39 / GPIO_MAX_NUM_PINS_PER_PORT, GPIO_PIN_P39 % GPIO_MAX_NUM_PINS_PER_PORT);
		mia_setKeepstate0(0x0);
		mia_setKeepstate1(0x80);
// 		AIR_POWER_Reset();
	}

	devlpm_init();
	devlpm_registerForLowPowerQueries(air_power_lpm_queriable, 2);

#ifdef AIR_POWER_EXTERNAL_32KHZ_OSC
	bleapputils_changeLPOSource(LPO_32KHZ_OSC, FALSE, 250);
#else
	bleapputils_changeLPOSource(LPO_MIA_LPO, FALSE, 500);
#endif

	bleprofile_regAppEvtHandler(BLECM_APP_EVT_ENTERING_HIDOFF, (BLECM_NO_PARAM_FUNC)AIR_POWER_enterHidoff);
	bleprofile_regAppEvtHandler(BLECM_APP_EVT_ABORTING_HIDOFF, (BLECM_NO_PARAM_FUNC)AIR_POWER_abortHidoff);
}

void AIR_POWER_Reset()
{
	bleappfwu_watchdogExpired(0);
}

void AIR_POWER_SetDeepSleepInterval(unsigned int value)
{
	deepsleepTimeInterval = value;
}

void AIR_POWER_SetMode(AIR_POWER_Mode mode)
{
	currentSleepMode = mode;

	if (currentSleepMode == AIR_POWER_OFF || currentSleepMode == AIR_POWER_VERYDEEPSLEEP)
	{
		bleapputils_delayUs(500);
		// Set the device to sleep now
		bleprofile_PrepareHidOff();              //Puts device into Deep Sleep ~1.33uA
		devlpm_timeToSleep();
	}

	else if (currentSleepMode == AIR_POWER_DEEPSLEEP)
	{
		gpio_configurePin(0, 0, 0x100, 0);
		devLpmConfig.disconnectedLowPowerMode = DEV_LPM_DISC_LOW_POWER_MODES_HID_OFF;
		devLpmConfig.wakeFromHidoffInMs = deepsleepTimeInterval;
#ifdef AIR_POWER_EXTERNAL_32KHZ_OSC
		devLpmConfig.wakeFromHidoffRefClk = HID_OFF_TIMED_WAKE_CLK_SRC_32KHZ;
#else
		devLpmConfig.wakeFromHidoffRefClk = HID_OFF_TIMED_WAKE_CLK_SRC_128KHZ;
#endif
		gpio_configurePin(0, 0, 0x100, 0);
		devlpm_enterLowPowerMode();
	}
}

AIR_POWER_Mode AIR_POWER_GetMode()
{
	return currentSleepMode;
}
