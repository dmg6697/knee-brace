#include "cloud/cloud.h"

BLEPROFILE_DB_PDU db_pdu;

void anaren_return_char(UINT16 handle, char value)
{
	db_pdu.len = 1;
	db_pdu.pdu[0] = value;

	bleprofile_WriteHandle(handle, &db_pdu);
}

void anaren_return_bool(UINT16 handle, char value)
{
	db_pdu.len = 1;
	db_pdu.pdu[0] = value;

	bleprofile_WriteHandle(handle, &db_pdu);
}

void anaren_return_int(UINT16 handle, int value)
{
	union
	{
		int variable;
		unsigned char temp_array[4];
	} u;

	u.variable = value;

	memcpy(db_pdu.pdu, u.temp_array, 4);

	db_pdu.len = 4;

	bleprofile_WriteHandle(handle, &db_pdu);
}

void anaren_return_float(UINT16 handle, float value)
{
	union
	{
		float variable;
		unsigned char temp_array[4];
	} u;

	u.variable = value;

	memcpy(db_pdu.pdu, u.temp_array, 4);

	db_pdu.len = 4;

	bleprofile_WriteHandle(handle, &db_pdu);
}

void anaren_return_double(UINT16 handle, double value)
{
	union
	{
		double variable;
		unsigned char temp_array[8];
	} u;

	u.variable = value;

	memcpy(db_pdu.pdu, u.temp_array, 8);

	db_pdu.len = 8;

	bleprofile_WriteHandle(handle, &db_pdu);
}

void anaren_return_string(UINT16 handle, char *data, unsigned int length)
{
	BLEPROFILE_DB_PDU* long_db_pdu = cfa_mm_Alloc(sizeof(UINT8) + sizeof(UINT8) + length);

	int i = 0;

	if (data != NULL)
	{
		for (i = 0; i < length; i++)
		{
			if (data[i] == 0)
			{
				long_db_pdu->pdu[i] = data[i];
				break;
			}

			long_db_pdu->pdu[i] = data[i];
		}
	}

	long_db_pdu->len = i + 1;

	if (i + 1 > 23)
	{
		bleprofile_WriteHandleData(handle, long_db_pdu, sizeof(UINT8) + sizeof(UINT8) + i + 1);
	}

	else
	{
		bleprofile_WriteHandle(handle, long_db_pdu);
	}

	cfa_mm_Free(long_db_pdu);
}

void anaren_return_json(UINT16 handle, char *data, unsigned int length)
{
	BLEPROFILE_DB_PDU* long_db_pdu = cfa_mm_Alloc(sizeof(UINT8) + sizeof(UINT8) + length);

	int i = 0;

	if (data != NULL)
	{
		for (i = 0; i < length; i++)
		{
			if (data[i] == 0)
			{
				break;
			}

			long_db_pdu->pdu[i] = data[i];
		}
	}

	else if (data == NULL || i == 0)
	{
		long_db_pdu->pdu[0] = 'n';
		long_db_pdu->pdu[1] = 'u';
		long_db_pdu->pdu[2] = 'l';
		long_db_pdu->pdu[3] = 'l';
		i = 4;
	}

	long_db_pdu->len = i;

	if (i > 23)
	{
		bleprofile_WriteHandleData(handle, long_db_pdu, sizeof(UINT8) + sizeof(UINT8) + i);
	}

	else
	{
		bleprofile_WriteHandle(handle, long_db_pdu);
	}

	cfa_mm_Free(long_db_pdu);
}

void anaren_make_cloud_credentials(UINT8 *attrPtr, unsigned int length)
{
	CLOUD_Registration stratReg;

	unsigned int i = 0;
	unsigned int j = 0;

	for (j = 0; j < 37 && i < length; i++, j++)
	{
		if ((char)attrPtr[i] != '|')
		{
			stratReg.uuid[j] = (char)attrPtr[i];
		}

		else
		{
			stratReg.uuid[j] = 0x00;
			break;
		}
	}

	i = i + 1;

	for (j = 0; j < 64 && i < length; i++, j++)
	{
		if ((char)attrPtr[i] != 0x00)
		{
			stratReg.token[j] = (char)attrPtr[i];
		}

		else
		{
			stratReg.token[j] = 0x00;
			break;
		}
	}

	CLOUD_SaveRegistration(&stratReg);

	return;
}

char anaren_make_char(UINT8 *attrPtr)
{
	return (char)attrPtr[0];
}

int anaren_make_int(UINT8 *attrPtr)
{
	union
	{
		int variable;
		unsigned char temp_array[4];
	} u;

	memcpy(u.temp_array, attrPtr, 4);

	return u.variable;
}

float anaren_make_float(UINT8 *attrPtr)
{
	union
	{
		float variable;
		unsigned char temp_array[4];
	} u;

	memcpy(u.temp_array, attrPtr, 4);

	return u.variable;
}

double anaren_make_double(UINT8 *attrPtr)
{
	union
	{
		double variable;
		unsigned char temp_array[8];
	} u;

	memcpy(u.temp_array, attrPtr, 8);

	return u.variable;
}