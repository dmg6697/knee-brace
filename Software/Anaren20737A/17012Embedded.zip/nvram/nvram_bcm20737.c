#include "nvram.h"
#include "../gpio/gpio.h"
#include "bleprofile.h"

void AIR_NVRAM_Init()
{
}

unsigned int AIR_NVRAM_Write(unsigned int block, unsigned char *data, unsigned int length)
{
	if (length > 256 || block < 0x10 || block > 0x6f) //Specific to the NVRAM on the BCM20737
	{
		return 0;
	}

	AIR_GPIO_SetMode(1, AIR_GPIO_OUTPUT_PUSH_PULL);
	
	AIR_GPIO_Write(1, false);
	return bleprofile_WriteNVRAM((UINT8)block, (UINT8)length, data);
	AIR_GPIO_Write(1, true);
	
	AIR_GPIO_SetMode(1, AIR_GPIO_INPUT_HIGH_IMPEDANCE);
}

unsigned int AIR_NVRAM_Read(unsigned int block, unsigned char *data, unsigned int length)
{
	if (length > 256 || block < 0x10 || block > 0x6f) //Specific to the NVRAM on the BCM20737
	{
		return 0;
	}

	return bleprofile_ReadNVRAM((UINT8)block, (UINT8)length, data);
}

void AIR_NVRAM_Delete(unsigned int block)
{
	if (block < 0x10 || block > 0x6f) //Specific to the NVRAM on the BCM20737
	{
		return;
	}
	
	AIR_GPIO_SetMode(1, AIR_GPIO_OUTPUT_PUSH_PULL);
	
	AIR_GPIO_Write(1, false);
	bleprofile_DeleteNVRAM((UINT8)block);
	AIR_GPIO_Write(1, true);
	
	AIR_GPIO_SetMode(1, AIR_GPIO_INPUT_HIGH_IMPEDANCE);

	return;
}
