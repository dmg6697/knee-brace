


int anaren_control_embedded_write_handler(UINT16 handle, int len, UINT8 *attrPtr)
{
	switch(handle)
	{

		case ATMOSPHERE_NOTIFY_DESCRIPTOR_HANDLE:
			if(len == 2)
			{
				anaren_control_hostinfo.characteristic_client_configuration = attrPtr[0] + (attrPtr[1] << 8);
				return 0;
			}

			return 0x80;
		break;

		case 0x18:
		{
			int retValue = ADCReadPot();
			anaren_return_int(0x18, retValue);
		
			return 0;
		}
		break;

		case 0x1a:
		{
			GPIOLEDEnable(anaren_make_char(attrPtr));
			char retValue = 0;
		
			return 0;
		}
		break;

		case 0x1c:
		{
			GPIOPinEnable(anaren_make_char(attrPtr));
			char retValue = 0;
		
			return 0;
		}
		break;

		case ATMOSPHERE_GATT_CLOUD_CREDENTIALS_HANDLE:
			anaren_make_cloud_credentials (attrPtr, len);
			return 0;
		break;
		
#ifdef BLE_OTA
		case HANDLE_WS_UPGRADE_CONTROL_POINT:
			if (len >= 1)
			{
				ws_upgrade_ota_handle_command (attrPtr, len);
				return 0;
			}
			return 0x80;
		break;
		case HANDLE_WS_UPGRADE_CLIENT_CONFIGURATION_DESCRIPTOR:
			if (len == 2)
			{
				ws_upgrade_ota_handle_configuration (attrPtr, len);
				return 0;
			}
			return 0x80;
		break;
		case HANDLE_WS_UPGRADE_DATA:
			if ((len > 0) && (len <= WS_UPGRADE_MAX_DATA_LEN))
			{
				ws_upgrade_ota_handle_data (attrPtr, len);
				return 0;
			}
			
			return 0x80;
		break;
#endif
		default:
			return 0x80;
		break;
	}
	
	return 0;
}

int anaren_control_write_handler(LEGATTDB_ENTRY_HDR *p)
{
	UINT16 handle = legattdb_getHandle(p);
	int len = legattdb_getAttrValueLen(p);
	UINT8  *attrPtr = legattdb_getAttrValue(p);
	return anaren_control_embedded_write_handler(handle, len, attrPtr);
}
