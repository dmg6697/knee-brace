#ifndef _PIN_MAPPING_H
#define _PIN_MAPPING_H

#define D0 32
#define D1 33
#define D2 3
// #define D3 NOT_CONNECTED
// #define D4 NOT_CONNECTED
#define D5 2
#define D6 27
// #define D7 NOT_CONNECTED
// #define D8 NOT_CONNECTED
#define D9 13
#define D10 14
#define D11 26
// #define D12 NOT_CONNECTED
#define D13 1
// #define D14 NOT_CONNECTED
// #define D15 NOT_CONNECTED
#define D16 33
#define D17 32
#define D18 14
#define D19 13
#define D20 0
#define D21 15

#define A0 15
#define A1 0
#define A2 13
#define A3 14
#define A4 32
#define A5 33

#define MOSI 4 
#define MISO 25
#define SCLK 24

#endif