
const UINT8 anaren_control_gatt_database[] =
{
	//Primary Service UUID:UUID_SERVICE_GATT:GATT Service
	PRIMARY_SERVICE_UUID16(
		0x1, 
		UUID_SERVICE_GATT),

	//Primary Service UUID:CLOUD_UUID:Cloud Service
	PRIMARY_SERVICE_UUID128(
		0x2, 
		CLOUD_UUID),

		//Characteristic UUID:CLOUD_CREDENTIAL_UUID:Cloud credential characteristic
		CHARACTERISTIC_UUID128_WRITABLE(
			0x3, //Handle
			0x4, //Handle Value
			CLOUD_CREDENTIAL_UUID, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ | LEGATTDB_CHAR_PROP_WRITE, //Property Flags
			LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_CMD | LEGATTDB_PERM_WRITE_REQ | LEGATTDB_PERM_RELIABLE_WRITE, //Permission Flags
			0x40), //Size
			0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,

		//Characteristic UUID:CLOUD_NOTIFY_UUID:Cloud notification characteristic
		CHARACTERISTIC_UUID128_WRITABLE(
			0x5, //Handle
			0x6, //Handle Value
			CLOUD_NOTIFY_UUID, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ | LEGATTDB_CHAR_PROP_WRITE | LEGATTDB_CHAR_PROP_NOTIFY, //Property Flags
			LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_CMD | LEGATTDB_PERM_WRITE_REQ | LEGATTDB_PERM_RELIABLE_WRITE, //Permission Flags
			0x80), //Size
			0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,

	//Primary Service UUID:UUID_SERVICE_GAP:GAP Service
	PRIMARY_SERVICE_UUID16(
		0x7, 
		UUID_SERVICE_GAP),

		//Characteristic UUID:UUID_CHARACTERISTIC_DEVICE_NAME:Appearance characteristic
		CHARACTERISTIC_UUID16(
			0x8, //Handle
			0x9, //Handle Value
			UUID_CHARACTERISTIC_DEVICE_NAME, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ, //Property Flags
			LEGATTDB_PERM_READABLE, //Permission Flags
			0x20), //Size
			'P','1','7','0','1','2',0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,

		//Characteristic UUID:UUID_CHARACTERISTIC_APPEARANCE:Appearance characteristic
		CHARACTERISTIC_UUID16(
			0xa, //Handle
			0xb, //Handle Value
			UUID_CHARACTERISTIC_APPEARANCE, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ, //Property Flags
			LEGATTDB_PERM_READABLE, //Permission Flags
			0x2), //Size
			BIT16_TO_8(APPEARANCE_GENERIC_TAG),

	//Primary Service UUID:UUID_SERVICE_DEVICE_INFORMATION:Device Information
	PRIMARY_SERVICE_UUID16(
		0xc, 
		UUID_SERVICE_DEVICE_INFORMATION),

		//Characteristic UUID:UUID_CHARACTERISTIC_MANUFACTURER_NAME_STRING:Manufacturer Name
		CHARACTERISTIC_UUID16(
			0xd, //Handle
			0xe, //Handle Value
			UUID_CHARACTERISTIC_MANUFACTURER_NAME_STRING, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ, //Property Flags
			LEGATTDB_PERM_READABLE, //Permission Flags
			0x6), //Size
			'A', 'n', 'a', 'r', 'e', 'n',

		//Characteristic UUID:UUID_CHARACTERISTIC_MODEL_NUMBER_STRING:Model Number
		CHARACTERISTIC_UUID16(
			0xf, //Handle
			0x10, //Handle Value
			UUID_CHARACTERISTIC_MODEL_NUMBER_STRING, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ, //Property Flags
			LEGATTDB_PERM_READABLE, //Permission Flags
			0x8), //Size
			'1', '2', '3', '4', 0x00, 0x00, 0x00, 0x00,

		//Characteristic UUID:UUID_CHARACTERISTIC_SYSTEM_ID:System ID
		CHARACTERISTIC_UUID16(
			0x11, //Handle
			0x12, //Handle Value
			UUID_CHARACTERISTIC_SYSTEM_ID, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ, //Property Flags
			LEGATTDB_PERM_READABLE, //Permission Flags
			0x8), //Size
			0x93,0xb8,0x63,0x80,0x5f,0x9f,0x91,0x71,

	//Primary Service UUID:ANAREN_SERVICE_UUID:Atmosphere Service
	PRIMARY_SERVICE_UUID128(
		0x13, 
		ANAREN_SERVICE_UUID),

		//Characteristic UUID:ANAREN_NOTIFY_UUID:Atmosphere Notify
		CHARACTERISTIC_UUID128(
			0x14, //Handle
			0x15, //Handle Value
			ANAREN_NOTIFY_UUID, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ | LEGATTDB_CHAR_PROP_NOTIFY, //Property Flags
			LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_READABLE, //Permission Flags
			0x80), //Size
			0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,

		CHAR_DESCRIPTOR_UUID16_WRITABLE(
			0x16,
			UUID_DESCRIPTOR_CLIENT_CHARACTERISTIC_CONFIGURATION,
			LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_REQ,
			0x2),
				0x0,0x0,

		//Characteristic UUID:ANAREN_UUID_ADCReadPot:ADCReadPot
		CHARACTERISTIC_UUID128_WRITABLE(
			0x17, //Handle
			0x18, //Handle Value
			ANAREN_UUID_ADCReadPot, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ | LEGATTDB_CHAR_PROP_WRITE, //Property Flags
			LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_CMD | LEGATTDB_PERM_WRITE_REQ | LEGATTDB_PERM_RELIABLE_WRITE, //Permission Flags
			0x4), //Size
			0x0,0x0,0x0,0x0,

		//Characteristic UUID:ANAREN_UUID_GPIOLEDEnable:GPIOLEDEnable
		CHARACTERISTIC_UUID128_WRITABLE(
			0x19, //Handle
			0x1a, //Handle Value
			ANAREN_UUID_GPIOLEDEnable, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ | LEGATTDB_CHAR_PROP_WRITE, //Property Flags
			LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_CMD | LEGATTDB_PERM_WRITE_REQ | LEGATTDB_PERM_RELIABLE_WRITE, //Permission Flags
			0x1), //Size
			0x0,

		//Characteristic UUID:ANAREN_UUID_GPIOPinEnable:GPIOPinEnable
		CHARACTERISTIC_UUID128_WRITABLE(
			0x1b, //Handle
			0x1c, //Handle Value
			ANAREN_UUID_GPIOPinEnable, //Characteristic UUID
			LEGATTDB_CHAR_PROP_READ | LEGATTDB_CHAR_PROP_WRITE, //Property Flags
			LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_CMD | LEGATTDB_PERM_WRITE_REQ | LEGATTDB_PERM_RELIABLE_WRITE, //Permission Flags
			0x1), //Size
			0x0,

	#ifdef BLE_OTA
	// Handle 0xff00: Broadcom vendor specific WICED Smart Upgrade Service.
	// The service has 2 characteristics.  The first is the control point.  Client
	// sends commands, and sensor sends status notifications. Note that
	// UUID of the vendor specific service is 16 bytes, unlike standard Bluetooth
	// UUIDs which are 2 bytes.  _UUID128 version of the macro should be used.
	PRIMARY_SERVICE_UUID128 (HANDLE_WS_UPGRADE_SERVICE, UUID_WS_UPGRADE_SERVICE),

	// Handle 0xff01: characteristic WS Control Point, handle 0xff02 characteristic value.
	// This characteristic can be used by the client to send commands to this device
	// and to send status notifications back to the client.  Client has to enable
	// notifications by updating Characteristic Client Configuration Descriptor
	// (see handle ff03 below).  Note that UUID of the vendor specific characteristic is
	// 16 bytes, unlike standard Bluetooth UUIDs which are 2 bytes.  _UUID128 version
	// of the macro should be used.  Also note that characteristic has to be _WRITABLE
	// to correctly enable writes from the client.
	CHARACTERISTIC_UUID128_WRITABLE (HANDLE_WS_UPGRADE_CHARACTERISTIC_CONTROL_POINT,
	HANDLE_WS_UPGRADE_CONTROL_POINT, UUID_WS_UPGRADE_CHARACTERISTIC_CONTROL_POINT,
	LEGATTDB_CHAR_PROP_WRITE | LEGATTDB_CHAR_PROP_NOTIFY | LEGATTDB_CHAR_PROP_INDICATE,
	LEGATTDB_PERM_WRITE_REQ | LEGATTDB_PERM_VARIABLE_LENGTH, 5),
	0x00,0x00,0x00,0x00,0x00,

	// Handle 0xff03: Characteristic Client Configuration Descriptor.
	// This is a standard GATT characteristic descriptor.  2 byte value 0 means that
	// message to the client is disabled.  Peer can write value 1 to enable
	// notifications or respectively.  Note _WRITABLE in the macro.  This
	// means that attribute can be written by the peer.
	CHAR_DESCRIPTOR_UUID16_WRITABLE (HANDLE_WS_UPGRADE_CLIENT_CONFIGURATION_DESCRIPTOR,
	UUID_DESCRIPTOR_CLIENT_CHARACTERISTIC_CONFIGURATION,
	LEGATTDB_PERM_READABLE | LEGATTDB_PERM_WRITE_REQ, 2),
	0x00,0x00,

	// Handle 0xff04: characteristic WS Data, handle 0xff05 characteristic value
	// This characteristic is used to send next portion of the FW.  Similar to the
	// control point, characteristic should be _WRITABLE and 128bit version of UUID is used.
	CHARACTERISTIC_UUID128_WRITABLE (HANDLE_WS_UPGRADE_CHARACTERISTIC_DATA,
	HANDLE_WS_UPGRADE_DATA, UUID_WS_UPGRADE_CHARACTERISTIC_DATA,
	LEGATTDB_CHAR_PROP_WRITE,
	LEGATTDB_PERM_VARIABLE_LENGTH | LEGATTDB_PERM_WRITE_REQ,  20),
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,

	// Handle 0xff06: characteristic Application Info, handle 0xff07 characteristic value
	// Client can read value of this characteristic to figure out which application id is
	// running as well as version information.  Characteristic UUID is 128 bits.
	CHARACTERISTIC_UUID128 (HANDLE_WS_UPGRADE_CHARACTERISTIC_APP_INFO,
	HANDLE_WS_UPGRADE_APP_INFO, UUID_WS_UPGRADE_CHARACTERISTIC_APP_INFO,
	LEGATTDB_CHAR_PROP_READ, LEGATTDB_PERM_READABLE,  4),
	ANAREN_CONTROL_APP_ID & 0xff, (ANAREN_CONTROL_APP_ID >> 8) & 0xff, ANAREN_CONTROL_APP_VERSION_MAJOR, ANAREN_CONTROL_APP_VERSION_MINOR,
	#endif
		
};