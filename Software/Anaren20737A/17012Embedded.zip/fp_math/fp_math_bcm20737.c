
#include "fp_math.h"

#define SINGLE_PRECISION_BIAS 127
#define DOUBLE_PRECISION_BIAS 1023

/**
 * 32 bit IEEE754
 * Bit 31 => Sign ( 1 Bit )
 * Bits 30 - 23 => Exponent ( 8 bits )
 * Bits 22 - 0 => Fraction ( 24 bits. 24th bit is implicitly assumed to be 1 )
 */
struct ieee754_binary32
{
	uint8_t sign;
	int8_t exp;
	uint32_t value;
};

/**
 * 32 bit IEEE754
 * Bit 63 => Sign ( 1 Bit )
 * Bits 62 - 52 => Exponent ( 11 bits )
 * Bits 51 - 0 => Fraction ( 52 bits. 52nd bit is implicitly assumed to be 1 )
 */
struct ieee754_binary64
{
	uint8_t sign;
	int16_t exp;
	uint64_t value;
};

static struct ieee754_binary32 Float2Struct(float val)
{
	struct ieee754_binary32 returnValue;
	union tmpVar
	{
		float floatVal;
		uint32_t intVal;
	} tmpValue;

	tmpValue.floatVal = val;

	returnValue.sign = (uint8_t)((tmpValue.intVal >> 31) & 0x01);
	returnValue.exp = (int8_t)((tmpValue.intVal >> 23) & 0xFF);
	returnValue.value = tmpValue.intVal & 0x007FFFFF;

	if (returnValue.exp != 0)
		returnValue.value |= 0x00800000;
	if (returnValue.value != 0)
		returnValue.exp -= SINGLE_PRECISION_BIAS;

	return returnValue;
}

static struct ieee754_binary64 Double2Struct(double val)
{
	struct ieee754_binary64 returnValue;
	union tmpVar
	{
		double doubleVal;
		uint64_t intVal;
	} tmpValue;

	tmpValue.doubleVal = val;

	returnValue.sign = (uint8_t)((tmpValue.intVal >> 63) & 0x01);
	returnValue.exp = (int16_t)((tmpValue.intVal >> 52) & 0x7FF);
	returnValue.value = tmpValue.intVal & 0x000FFFFFFFFFFFFF;

	if (returnValue.exp != 0)
		returnValue.value |= 0x0010000000000000;
	returnValue.exp -= DOUBLE_PRECISION_BIAS;

	return returnValue;
}

static float Struct2Float(struct ieee754_binary32 *val)
{
	union tmpVar
	{
		float floatVal;
		uint32_t intVal;
	} tmpValue;
	int8_t tmpExp = val->exp + SINGLE_PRECISION_BIAS;

	tmpValue.intVal = val->value;

	if (tmpValue.intVal == 0)
	{
		tmpExp = 0;
	}
	else
	{
		// Normalize the result
		while (tmpValue.intVal >= 0x01000000)
		{
			tmpValue.intVal >>= 1;
			tmpExp += 1;
		}

		while (tmpValue.intVal < 0x00800000)
		{
			tmpValue.intVal <<= 1;
			tmpExp -= 1;
		}
	}

	tmpValue.intVal &= 0x007FFFFF;
	tmpValue.intVal |= ((int32_t)tmpExp & 0xFF) << 23;
	tmpValue.intVal |= ((uint32_t)val->sign & 0x01) << 31;

	float floatVal = tmpValue.floatVal;

	return floatVal;
}

static double Struct2Double(struct ieee754_binary64 *val)
{
	union tmpVar
	{
		double doubleVal;
		uint64_t intVal;
	} tmpValue;
	int16_t tmpExp = val->exp + DOUBLE_PRECISION_BIAS;

	tmpValue.intVal = val->value;

	if (tmpValue.intVal == 0)
	{
		tmpExp = 0;
	}
	else
	{
		while (tmpValue.intVal >= 0x0020000000000000)
		{
			tmpValue.intVal >>= 1;
			tmpExp += 1;
		}
	}

	tmpValue.intVal &= 0x000FFFFFFFFFFFFF;
	tmpValue.intVal |= ((int64_t)tmpExp & 0x7FF) << 52;
	tmpValue.intVal |= ((uint64_t)val->sign & 0x01) << 63;

	double doubleVal = tmpValue.doubleVal;

	return doubleVal;
}


/**
 * This routine will compare the two parameters.
 *
 * @param a :Specifies the value that is going to be compared.
 * @param b :Specifies the value that is going to be compared.
 * @return This routine returns a 1 if a parameter is greater than b parameter, 0 if the two parameters are equal to each other, and -1 if a parameter is less than b parameter.
 */
int8_t fp_cmp(float a, float b)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);
	struct ieee754_binary32 b_struct = Float2Struct(b);

	// a is pos, b is neg
	if (!a_struct.sign && b_struct.sign)
		return 1;

	// a is neg, b is pos
	if (a_struct.sign && !b_struct.sign)
		return -1;

	// a is pos, b is pos
	if (!a_struct.sign && !b_struct.sign)
	{
		if ((a_struct.value == 0) && (b_struct.value != 0))
			return -1;
		if ((b_struct.value == 0) && (a_struct.value != 0))
			return 1;

		if (a_struct.exp > b_struct.exp)
			return 1;
		if (a_struct.exp < b_struct.exp)
			return -1;

		if (a_struct.value > b_struct.value)
			return 1;
		if (a_struct.value < b_struct.value)
			return -1;
		return 0;
	}

	// a is neg, b is neg
	if ((a_struct.value == 0) && (b_struct.value != 0))
		return 1;
	if ((b_struct.value == 0) && (a_struct.value != 0))
		return -1;

	if (a_struct.exp < b_struct.exp)
		return 1;
	if (a_struct.exp > b_struct.exp)
		return -1;

	if (a_struct.value < b_struct.value)
		return 1;
	if (a_struct.value > b_struct.value)
		return -1;
	return 0;
}

/**
 * This routine will add two parameters together.
 *
 * @param a :Specifies the first value to add together.
 * @param b :Specifies the second value to add together.
 * @return This routine returns the sum of the two parameters.
 */
float fp_add(float a, float b)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);
	struct ieee754_binary32 b_struct = Float2Struct(b);
	struct ieee754_binary32 result;

	// Make sure the exponents are the same before adding
	if (a_struct.exp > b_struct.exp)
	{
		b_struct.value >>= (a_struct.exp - b_struct.exp);
		result.exp = a_struct.exp;
	}
	else if (b_struct.exp > a_struct.exp)
	{
		a_struct.value >>= (b_struct.exp - a_struct.exp);
		result.exp = b_struct.exp;
	}
	else
	{
		result.exp = a_struct.exp;
	}

	// Negate if necessary
	if (a_struct.sign)
	{
		a_struct.value ^= 0xFFFFFFFF;
		a_struct.value += 1;
	}

	if (b_struct.sign)
	{
		b_struct.value ^= 0xFFFFFFFF;
		b_struct.value += 1;
	}

	// Add the values
	result.value = a_struct.value + b_struct.value;
	result.sign = (result.value >> 31) & 0x01;

	// Negate result if necessary
	if (result.sign)
	{
		result.value -= 1;
		result.value ^= 0xFFFFFFFF;
	}

	return Struct2Float(&result);
}

/**
 * This routine will multiply two parameters together.
 *
 * @param a :Specifies the first value to multiply together.
 * @param b :Specifies the second value to multiply together.
 * @return This routine returns the product of the two parameters.
 */
float fp_mult(float a, float b)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);
	struct ieee754_binary32 b_struct = Float2Struct(b);
	struct ieee754_binary32 result;
	uint64_t tmpValue;

	result.sign = a_struct.sign ^ b_struct.sign;
	result.exp = a_struct.exp + b_struct.exp;
	tmpValue = (uint64_t)a_struct.value * (uint64_t)b_struct.value;
	result.value = (uint32_t)(tmpValue >> 23);

	return Struct2Float(&result);
}

/**
 * This routine will subtract two parameters together.
 *
 * @param a :Specifies the first value to subtract together.
 * @param b :Specifies the second value to subtract together.
 * @return This routine returns the difference of the two parameters.
 */
float fp_sub(float a, float b)
{
	return fp_add(a, fp_mult(b, -1.0));
}

/**
 * This routine will divide the two parameters together.
 *
 * @param a :Specifies the first value to divide together.
 * @param b :Specifies the second value to divide together.
 * @return This routine returns the quotient of the two parameters.
 */
float fp_div(float a, float b)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);
	struct ieee754_binary32 b_struct = Float2Struct(b);
	struct ieee754_binary32 result;

	// Don't want to bust open a hole in the universe
	if (fp_cmp(b, 0.0) == 0)
	{
		return 0.0;
	}

	result.sign = a_struct.sign ^ b_struct.sign;
	result.exp = a_struct.exp - b_struct.exp;

	// Extend the divisor to be 48 bits
	uint64_t tmpDivisor = ((uint64_t)a_struct.value << 23);
	result.value = ((tmpDivisor) / (b_struct.value));

	return Struct2Float(&result);
}

/**
 * This routine will take a parameter and raise it to the power of n parameter.
 *
 * @param a :Specifies the base to be raised.
 * @param n :Specifies the exponent to be raised to.
 * @return This routine returns the power of the two parameters.
 */
float fp_pow(float a, int16_t n)
{
    float result = 1;
    for(; n < 0; n++)
    {
        result /= a;
    }
    for(; n > 0; n--)
    {
        result *= a;
    }
    return result;
}

/**
 * This routine will produce the square root of a parameter.
 *
 * @param a :Specifies the value to be square rooted.
 * @return This routine returns the square root of the parameter.
 */
float fp_sqrt(float a)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);

	union tmpUnion
	{
		float floatVal;
		uint32_t intVal;
	} tmpValue;

	tmpValue.floatVal = a;

	// No imaginary numbers
	if (fp_cmp(a, 0.0) == -1)
	{
		tmpValue.intVal = 0x7FFFFFFF;

		return tmpValue.floatVal;
	}

	if (fp_cmp(a, 0.0) == 0)
		return 0.0;

	// http://www.codeproject.com/Articles/69941/Best-Square-Root-Method-Algorithm-Function-Precisi
	// method 1
	// Does some dirty IEEE floating point stuff along with two babylonian steps to get a pretty good
	// square root approximation
	tmpValue.intVal = (1 << 29) + (tmpValue.intVal >> 1) - (1 << 22);

	// Two Babylonian Steps
	// u.x = 0.5f * (u.x + x/u.x);
	// u.x = 0.5f * (u.x + x/u.x);
	tmpValue.floatVal = fp_mult(0.5,
								fp_add(tmpValue.floatVal, fp_div(a, tmpValue.floatVal)));
	tmpValue.floatVal = fp_mult(0.5,
								fp_add(tmpValue.floatVal, fp_div(a, tmpValue.floatVal)));

	return tmpValue.floatVal;
}

// Broadcom specific functions.  These allow using standard math operators such as + - * / in the source code.
float __aeabi_ui2f(unsigned int a)
{
	struct ieee754_binary32 result;
	uint64_t tempVar64;
	uint16_t tempVar16 = (uint16_t)a;

	result.sign = (tempVar16 >> 15) & 0x01;
	result.exp = 0;

	result.value = (result.sign) ? (tempVar16 - 1) ^ 0xFFFF : tempVar16;
	tempVar64 = (uint64_t)result.value << 23;
	while (tempVar64 >= 0x01000000)
	{
		tempVar64 >>= 1;
		result.exp += 1;
	}
	result.value = tempVar64;

	return Struct2Float(&result);
}

double __aeabi_ui2d(unsigned int a)
{
	return (double)__aeabi_ui2f(a);
}

float __aeabi_fmul(float a, float b)
{
	return fp_mult(a, b);
}

float __aeabi_fdiv(float a, float b)
{
	return fp_div(a, b);
}

float __aeabi_fadd(float a, float b)
{
	return fp_add(a, b);
}

float __aeabi_fsub(float a, float b)
{
	return fp_sub(a, b);
}

double __aeabi_f2d(float a)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);
	struct ieee754_binary64 result;

	result.sign = a_struct.sign;
	result.exp = (int16_t)a_struct.exp;
	result.value = (uint64_t)a_struct.value << 29;

	return Struct2Double(&result);
}

float __aeabi_d2f(double a)
{
	struct ieee754_binary64 a_struct = Double2Struct(a);
	struct ieee754_binary32 result;

	result.sign = a_struct.sign;
	result.exp = a_struct.exp & 0xFF;
	result.value = (a_struct.value >> 29) & 0x00FFFFFF;

	return Struct2Float(&result);
}

float __aeabi_i2f(int16_t a)
{
	struct ieee754_binary32 result;
	uint64_t tempVar64;
	uint16_t tempVar16 = (uint16_t)a;

	result.sign = (tempVar16 >> 15) & 0x01;
	result.exp = 0;

	result.value = (result.sign) ? (tempVar16 - 1) ^ 0xFFFF : tempVar16;
	tempVar64 = (uint64_t)result.value << 23;
	while (tempVar64 >= 0x01000000)
	{
		tempVar64 >>= 1;
		result.exp += 1;
	}
	result.value = tempVar64;

	return Struct2Float(&result);
}

double __aeabi_i2d(int16_t a)
{
	return __aeabi_f2d(__aeabi_i2f(a));
}

int16_t __aeabi_f2iz(float a)
{
	struct ieee754_binary32 a_struct = Float2Struct(a);
	int64_t tempVar = (int64_t)a_struct.value;
	int32_t result;

	if (a_struct.exp < 0)
		return 0;

	if (a_struct.exp > 0)
	{
		tempVar <<= a_struct.exp;
		a_struct.exp -= a_struct.exp;
	}

	result = tempVar >> 23;

	if (result > 0x7FFF)
	{
		result = a_struct.sign ? 0x8000 : 0x7FFF;
	}

	if (a_struct.sign)
	{
		result ^= 0xFFFF;
		result += 1;
	}

	return (int16_t)result;
}

uint16_t __aeabi_d2iz(double a)
{
	return __aeabi_f2iz((float)a);
}

uint16_t __aeabi_f2uiz(float a)
{
	return (uint16_t)__aeabi_f2iz(a);
}

uint16_t __aeabi_d2uiz(double a)
{
	return (uint16_t)__aeabi_f2iz(__aeabi_d2f(a));
}

int8_t __aeabi_fcmpeq(float a, float b)
{
	return (fp_cmp(a, b) == 0) ? 1 : 0;
}

int8_t __aeabi_dcmpeq(double a, double b)
{
	return __aeabi_fcmpeq((float)a, (float)b);
}

int8_t __aeabi_fcmpge(float a, float b)
{
	return(fp_cmp(a, b) >= 0);
}

int8_t __aeabi_fcmple(float a, float b)
{
	return(fp_cmp(a, b) <= 0);
}

int8_t __aeabi_fcmpgt(float a, float b)
{
	return(fp_cmp(a, b) > 0);
}

int8_t __aeabi_fcmplt(float a, float b)
{
	return(fp_cmp(a, b) < 0);
}

double pow(double a, double n)
{
	return fp_pow(a, n);
}

double sqrt(double a)
{
	return fp_sqrt(a);
}

double ldexp(double a, int16_t n)
{
	return fp_pow(a, n);
}