#include "bleprofile.h"
#include "../air_gatt_defines.h"

void ATMOSPHERE_NotifyFunction(unsigned int functionId, char *data)
{
	char buffer[128];
	int i = 0;

	buffer[0] = 0x05;
	buffer[1] = functionId;

	for (i = 0; i + 2 < 126; i++)
	{
		if (data[i] == 0)
		{
			break;
		}

		buffer[i + 2] = data[i];
	}

	bleprofile_sendNotification(ATMOSPHERE_NOTIFY_HANDLE, (UINT8*)buffer, i + 2);
}