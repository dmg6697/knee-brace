// Copyright (c) 2014, Anaren Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies,
// either expressed or implied, of the FreeBSD Project.



#define BLE_TRACE_DISABLE

#include "bleprofile.h"
#include "bleapp.h"
#include "gpiodriver.h"
#include "spiffydriver.h"
#include "string.h"
#include "stdio.h"
#include "platform.h"
#include "bleappconfig.h"
#include "cfa.h"
#include "devicelpm.h"
#include "spar_utils.h" // sprintf, J-Link debug
#include "callbacks.h"
#include "ble/ble.h"
#include "ble/ble_config.h"
#include "uart/uart.h"
#include "miadriver.h"
#include "long_characteristic_support.h"
#include "additional_advertisement_control.h"

#ifdef BLE_OTA
#include "ws_upgrade_ota.h"
#endif

#define SLEEP 1
#define DEEPSLEEP 2

#ifdef BLE_PAIRING_NONE
#define BLE_SECURITY_FLAGS 0
#else
#define BLE_SECURITY_FLAGS (SECURITY_ENABLED | SECURITY_REQUEST)
#endif

#ifdef BLE_OTA
#define ANAREN_CONTROL_APP_ID             0x3A19
#define ANAREN_CONTROL_APP_VERSION_MAJOR  1
#define ANAREN_CONTROL_APP_VERSION_MINOR  1

const WS_UPGRADE_APP_INFO WsUpgradeAppInfo =
{
	/* ID            = */ ANAREN_CONTROL_APP_ID,
	/* Version_Major = */ ANAREN_CONTROL_APP_VERSION_MAJOR,
	/* Version_Minor = */ ANAREN_CONTROL_APP_VERSION_MINOR,
};
#endif

#include "gatt/gatt.h"
#include "air_gatt_defines.h"
#include "air_gatt_db.h"

#include "aclk.h"


/******************************************************
*                      Constants
******************************************************/
// Uncomment the following line to enable OOB pairing. Change oob_tk[] below to the desired key.

#ifdef BLE_PAIRING_OOB
#define OOB_PAIRING
#endif

// Uncomment the following line to enable passkey pairing. Change passKey[] below to the desired key.
#ifdef BLE_PAIRING_PASSKEY
#define PASSKEY_PAIRING
#endif

#define NVRAM_ID_HOST_LIST                                      0x10    // ID of the memory block used for NVRAM access

#ifdef OOB_PAIRING
const UINT8 oob_tk[LESMP_MAX_KEY_SIZE] = { 0x41, 0x59, 0x1c, 0xd5, 0xea, 0x5a, 0x49, 0x55, 0xb6, 0x3b, 0x18, 0x7c, 0x46, 0xe, 0x13, 0x52 };
#endif

#ifdef PASSKEY_PAIRING
//passkey=123456
const UINT8 passKey[LESMP_MAX_KEY_SIZE] = { 0x40, 0xE2, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
#endif

const UINT8 AppGuid[16] = { ANAREN_SERVICE_UUID };
const UINT16 VerMajor = 1;
const UINT16 VerMinor = 1;



/******************************************************
*                     Structures
******************************************************/

#pragma pack(1)
//host information for NVRAM
typedef PACKED struct
{
	// BD address of the bonded host
	BD_ADDR bdaddr;

	// Current value of the client configuration descriptor
	UINT16 characteristic_client_configuration;

	// sensor configuration. number of times to blink when button is pushed.
	UINT8 number_of_blinks;
}  HOSTINFO;
#pragma pack()

/******************************************************
*               Function Prototypes
******************************************************/

static void anaren_control_create(void);
static void anaren_control_timeout(UINT32 count);
static void anaren_control_fine_timeout(UINT32 finecount);
static void anaren_control_database_init(void);
static void anaren_control_connection_up(void);
static void anaren_control_connection_down(void);
static void anaren_control_advertisement_stopped(void);
static void anaren_control_smp_bond_result(LESMP_PARING_RESULT result);
static void anaren_control_encryption_changed(HCI_EVT_HDR *evt);
static void anaren_control_send_message(void);
static int  anaren_control_write_handler(LEGATTDB_ENTRY_HDR *p);
static void anaren_control_indication_cfm(void);
static void anaren_control_interrupt_handler(UINT8 value);

void anaren_advertisement_packet_transmission(UINT8 type);

extern void bleprofile_appTimerCb(UINT32 arg);

/******************************************************
*               Variables Definitions
******************************************************/

const BLE_PROFILE_CFG anaren_control_cfg =
{
	/*.fine_timer_interval            =*/ BLE_INTERVAL_FINE_TIMER, // ms
	/*.default_adv                    =*/ 4, // HIGH_UNDIRECTED_DISCOVERABLE
	/*.button_adv_toggle              =*/ 0, // pairing button make adv toggle (if 1) or always on (if 0)
	/*.high_undirect_adv_interval     =*/ 32, // slots
	/*.low_undirect_adv_interval      =*/ 1024, // slots
	/*.high_undirect_adv_duration     =*/ 30, // seconds
	/*.low_undirect_adv_duration      =*/ 300, // seconds
	/*.high_direct_adv_interval       =*/ 0, // seconds
	/*.low_direct_adv_interval        =*/ 0, // seconds
	/*.high_direct_adv_duration       =*/ 0, // seconds
	/*.low_direct_adv_duration        =*/ 0, // seconds
	/*.local_name                     =*/ BLE_LOCAL_NAME,    // [LOCAL_NAME_LEN_MAX];
	/*.cod                            =*/ BIT16_TO_8(APPEARANCE_GENERIC_TAG), 0x00, // [COD_LEN];
	/*.ver                            =*/ BLE_VERSION,     // [VERSION_LEN];
	/*.encr_required                  =*/ BLE_SECURITY_FLAGS, // data encrypted and device sends security request on every connection
	/*.disc_required                  =*/ 0, // if 1, disconnection after confirmation
	/*.test_enable                    =*/ 0, // TEST MODE is enabled when 1
	/*.tx_power_level                 =*/ BLE_TX_POWER_LEVEL, // dbm
	/*.con_idle_timeout               =*/ 3, // second  0-> no timeout
	/*.powersave_timeout              =*/ 0, // second  0-> no timeout
	/*.hdl                            =*/ { 0x00, 0x0063, 0x00, 0x00, 0x00 }, // [HANDLE_NUM_MAX];
	/*.serv                           =*/ { 0x00, UUID_SERVICE_BATTERY, 0x00, 0x00, 0x00 },
	/*.cha                            =*/ { 0x00, UUID_CHARACTERISTIC_BATTERY_LEVEL, 0x00, 0x00, 0x00 },
	/*.findme_locator_enable          =*/ 0, // if 1 Find me locator is enable
	/*.findme_alert_level             =*/ 0, // alert level of find me
	/*.client_grouptype_enable        =*/ 0, // if 1 grouptype read can be used
	/*.linkloss_button_enable         =*/ 0, // if 1 linkloss button is enable
	/*.pathloss_check_interval        =*/ 0, // second
	/*.alert_interval                 =*/ 0, // interval of alert
	/*.high_alert_num                 =*/ 0, // number of alert for each interval
	/*.mild_alert_num                 =*/ 0, // number of alert for each interval
	/*.status_led_enable              =*/ 0, // if 1 status LED is enable
	/*.status_led_interval            =*/ 0, // second
	/*.status_led_con_blink           =*/ 0, // blink num of connection
	/*.status_led_dir_adv_blink       =*/ 0, // blink num of dir adv
	/*.status_led_un_adv_blink        =*/ 0, // blink num of undir adv
	/*.led_on_ms                      =*/ 0, // led blink on duration in ms
	/*.led_off_ms                     =*/ 0, // led blink off duration in ms
	/*.buz_on_ms                      =*/ 100, // buzzer on duration in ms
	/*.button_power_timeout           =*/ 0, // seconds
	/*.button_client_timeout          =*/ 0, // seconds
	/*.button_discover_timeout        =*/ 0, // seconds
	/*.button_filter_timeout          =*/ 0, // seconds
#ifdef BLE_UART_LOOPBACK_TRACE
	/*.button_uart_timeout            =*/ 15, // seconds
#endif
};

// Following structure defines GPIO configuration used by the application
const BLE_PROFILE_GPIO_CFG anaren_control_gpio_cfg =
{
	/*.gpio_pin =*/
	{
		GPIO_PIN_WP, // This need to be used to enable/disable NVRAM write protect
		-1, // Button GPIO is configured to trigger either direction of interrupt
		-1, // LED GPIO, optional to provide visual effects
		-1, // Battery monitoring GPIO. When it is lower than particular level, it will give notification to the application
		-1, // Buzzer GPIO, optional to provide audio effects
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 // other GPIOs are not used
	},
	/*.gpio_flag =*/
	{
		GPIO_SETTINGS_WP,
		0,
		0,
		0,
		0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
	}
};


// UINT32 anaren_control_timer_count = 0;
UINT16 anaren_control_connection_handle = 0;      // HCI handle of connection, not zero when connected
BD_ADDR anaren_control_remote_addr = { 0, 0, 0, 0, 0, 0 };
UINT8 anaren_control_indication_sent = 0;         // indication sent, waiting for ack
UINT8 anaren_control_num_to_write = 0;            // Number of messages we need to send
UINT8 anaren_control_stay_connected = 1;                  // Change that to 0 to disconnect when all messages are sent

const BLE_PROFILE_PUART_CFG anaren_puart_cfg =
{
	115200, // UINT32 baudrate;
	32, // 31, // 32, // UINT8  txpin; //GPIO pin number //20730A0 module need to use 32 instead, normally it is 31
	33, // UINT8  rxpin; //GPIO pin number
};

// NVRAM save area
HOSTINFO anaren_control_hostinfo;

#include "anaren_utils.h"
#include "write_handler.h"

/******************************************************
*               Function Definitions
******************************************************/

// Application initialization
APPLICATION_INIT()
{
	bleapp_set_cfg((UINT8*)anaren_control_gatt_database,
		       sizeof(anaren_control_gatt_database),
		       (void*)&anaren_control_cfg,
		       (void*)&anaren_puart_cfg,
		       (void*)&anaren_control_gpio_cfg,
		       anaren_control_create);
}

void anaren_control_create(void)
{
	extern UINT32 blecm_configFlag;

	blecm_configFlag = 0;

	bleprofile_Init(bleprofile_p_cfg);

	bleprofile_GPIOInit(bleprofile_gpio_p_cfg);

	anaren_control_database_init();    //load handle number

	// register connection up and connection down handler.
	bleprofile_regAppEvtHandler(BLECM_APP_EVT_LINK_UP, anaren_control_connection_up);
	bleprofile_regAppEvtHandler(BLECM_APP_EVT_LINK_DOWN, anaren_control_connection_down);
	bleprofile_regAppEvtHandler(BLECM_APP_EVT_ADV_TIMEOUT, anaren_control_advertisement_stopped);

#if defined OOB_PAIRING || defined PASSKEY_PAIRING
	// setup the pairing parameters.
	lesmp_setPairingParam(
		LESMP_IO_CAP_DISP_ONLY,
#ifdef OOB_PAIRING
		LESMP_OOB_AUTH_DATA_FROM_REMOTE_PRESENT, // OOBDataFlag,
#else
		LESMP_OOB_AUTH_DATA_NOT_PRESENT, // OOBDataFlag,
#endif
#ifdef PASSKEY_PAIRING
		LESMP_AUTH_FLAG_BONDING                 // AuthReq,
		| LESMP_AUTH_REQ_FLAG_MITM,
#else
		LESMP_AUTH_FLAG_BONDING,                // AuthReq,
#endif
		LESMP_MAX_KEY_SIZE,             // MaxEncKeySize,
	        // InitiatorKeyDistrib,
		LESMP_KEY_DISTRIBUTION_ENC_KEY
		| LESMP_KEY_DISTRIBUTION_ID_KEY
		| LESMP_KEY_DISTRIBUTION_SIGN_KEY,
	        // ResponderKeyDistrib
		LESMP_KEY_DISTRIBUTION_ENC_KEY
		| LESMP_KEY_DISTRIBUTION_ID_KEY
		| LESMP_KEY_DISTRIBUTION_SIGN_KEY
		);
#ifdef OOB_PAIRING
	lesmp_setSMPOOBdata((UINT8*)oob_tk, LESMP_MAX_KEY_SIZE);
	lesmp_setJustWorksNotPermitted();
	lesmp_setPasskeyEntryNotPermitted();
#endif
#ifdef PASSKEY_PAIRING
	lesmp_setSMPassKey((UINT8*)passKey, LESMP_MAX_KEY_SIZE);
	lesmp_setJustWorksNotPermitted();
#endif
#endif
	// handler for Encryption changed.
	blecm_regEncryptionChangedHandler(anaren_control_encryption_changed);

	// handler for Bond result
	lesmp_regSMPResultCb((LESMP_SINGLE_PARAM_CB)anaren_control_smp_bond_result);

	// register to process client writes
	legattdb_regWriteHandleCb((LEGATTDB_WRITE_CB)anaren_control_write_handler);

	// register interrupt handler
	bleprofile_regIntCb((BLEPROFILE_SINGLE_PARAM_CB)anaren_control_interrupt_handler);

	bleprofile_KillTimer();
	bleprofile_regTimerCb(anaren_control_fine_timeout, anaren_control_timeout);
	bleprofile_StartTimer();

	aclk_configure(512000, ACLK1, ACLK_FREQ_24_MHZ);

	// register with LE stack to be called 2.5msec before the advertisement event
	bleprofile_notifyAdvPacketTransmissions(&anaren_advertisement_packet_transmission, 2500);

	blecm_setTxPowerInADV(0);

#ifdef BLE_OTA
	ws_upgrade_ota_init();
#endif

	blecm_setTxPowerInADV(ADV_BLE_TX_POWER_LEVEL);
	blecm_setTxPowerInConnection(BLE_TX_POWER_LEVEL);
	
	CLOUD_Init();
	
	setup();

	// Start advertisements
	AIR_BLE_SetDiscoverable(true);
}

// Initialize GATT database
void anaren_control_database_init(void)
{
	//Initialized ROM code which will monitor the battery
	//blebat_Init();
}

// This function will be called on every connection establishmen
void anaren_control_connection_up(void)
{
	UINT8 writtenbyte;
	UINT8 *bda;

	anaren_control_connection_handle = (UINT16)emconinfo_getConnHandle();

	// save address of the connected device and print it out.
	memcpy(anaren_control_remote_addr, (UINT8*)emconninfo_getPeerPubAddr(), sizeof(anaren_control_remote_addr));

	// Stop advertising
	AIR_BLE_SetDiscoverable(false);

	bleprofile_StopConnIdleTimer();

	// as we require security for every connection, we will not send any indications until
	// encryption is done.
	if (bleprofile_p_cfg->encr_required != 0)
	{
		if (!emconninfo_deviceBonded())
		{
			lesmp_pinfo->pairingParam.AuthReq |= LESMP_AUTH_FLAG_BONDING;
			lesmp_sendSecurityRequest();
		}

		connected();
		return;
	}
	// saving bd_addr in nvram

	bda = (UINT8*)emconninfo_getPeerPubAddr();

	memcpy(anaren_control_hostinfo.bdaddr, bda, sizeof(BD_ADDR));
	anaren_control_hostinfo.characteristic_client_configuration = 0;
	anaren_control_hostinfo.number_of_blinks = 0;

	writtenbyte = bleprofile_WriteNVRAM(NVRAM_ID_HOST_LIST, sizeof(anaren_control_hostinfo), (UINT8*)&anaren_control_hostinfo);

	anaren_control_encryption_changed(NULL);

	bleprofile_SendConnParamUpdateReq(BLE_INTERVAL_MIN, BLE_INTERVAL_MAX, BLE_SLAVE_LATENCY, BLE_CONNECTION_TIMEOUT);

	connected();
}

// This function will be called when connection goes down
void anaren_control_connection_down(void)
{
	memset(anaren_control_remote_addr, 0, 6);
	anaren_control_connection_handle = 0;

	if (anaren_control_stay_connected)
	{
		bleprofile_Discoverable(LOW_UNDIRECTED_DISCOVERABLE, anaren_control_hostinfo.bdaddr);
	}

	else
	{
		AIR_BLE_SetDiscoverable(true);
	}

	disconnected();
}

void anaren_control_advertisement_stopped(void)
{
	if (anaren_control_stay_connected)
	{
		bleprofile_Discoverable(LOW_UNDIRECTED_DISCOVERABLE, anaren_control_hostinfo.bdaddr);
	}
}

void anaren_control_timeout(UINT32 arg)
{
}

void anaren_control_fine_timeout(UINT32 arg)
{
	interval();
}

void anaren_advertisement_packet_transmission(UINT8 type)
{
	if (type == 0)
	{
		BLEPROFILE_DB_PDU db_pdu;

		bleprofile_ReadHandle(ATMOSPHERE_SERVICE_HANDLE, &db_pdu);

		if (db_pdu.len == 16)
		{
			// total length should be less than 31 bytes
			BLE_ADV_FIELD adv[3];

			// flags
			adv[0].len = 1 + 1;
			adv[0].val = ADV_FLAGS;
			adv[0].data[0] = LE_LIMITED_DISCOVERABLE | BR_EDR_NOT_SUPPORTED;

			adv[1].len = 16 + 1;
			adv[1].val = ADV_SERVICE_UUID128_COMP;
			memcpy(adv[1].data, db_pdu.pdu, 16);

			// name
			adv[2].len = strlen(bleprofile_p_cfg->local_name) + 1;
			adv[2].val = ADV_LOCAL_NAME_COMP;
			memcpy(adv[2].data, bleprofile_p_cfg->local_name, adv[2].len - 1);

			bleprofile_GenerateADVData(adv, 3);
			bleprofile_GenerateScanRspData(&adv[2], 1);
		}
	}
}

//
// Process SMP bonding result.  If we successfully paired with the
// central device, save its BDADDR in the NVRAM and initialize
// associated data
//
void anaren_control_smp_bond_result(LESMP_PARING_RESULT result)
{
	if (result == LESMP_PAIRING_RESULT_BONDED)
	{
		// saving bd_addr in nvram
		UINT8 *bda;
		UINT8 writtenbyte;

		bda = (UINT8*)emconninfo_getPeerPubAddr();

		memcpy(anaren_control_hostinfo.bdaddr, bda, sizeof(BD_ADDR));
		anaren_control_hostinfo.characteristic_client_configuration = 0;
		anaren_control_hostinfo.number_of_blinks = 0;

		writtenbyte = bleprofile_WriteNVRAM(NVRAM_ID_HOST_LIST, sizeof(anaren_control_hostinfo), (UINT8*)&anaren_control_hostinfo);
	}
}

//
// Process notification from the stack that encryption has been set.  If connected
// client is registered for notification or indication, it is a good time to
// send it out
//
void anaren_control_encryption_changed(HCI_EVT_HDR *evt)
{
	BLEPROFILE_DB_PDU db_pdu;

	UINT8 *bda = emconninfo_getPeerPubAddr();

	// Connection has been encrypted meaning that we have correct/paired device
	// restore values in the database
	bleprofile_ReadNVRAM(NVRAM_ID_HOST_LIST, sizeof(anaren_control_hostinfo), (UINT8*)&anaren_control_hostinfo);

	db_pdu.len = 2;
	db_pdu.pdu[0] = anaren_control_hostinfo.characteristic_client_configuration & 0xff;
	db_pdu.pdu[1] = (anaren_control_hostinfo.characteristic_client_configuration >> 8) & 0xff;

	bleprofile_WriteHandle(ATMOSPHERE_NOTIFY_DESCRIPTOR_HANDLE, &db_pdu);


	// If there are outstanding messages that we could not send out because
	// connection was not up and/or encrypted, send them now.  If we are sending
	// indications, we can send only one and need to wait for ack.
	while ((anaren_control_num_to_write != 0) && !anaren_control_indication_sent)
	{
		anaren_control_num_to_write--;
		anaren_control_send_message();
	}

	// If configured to disconnect after delivering data, start idle timeout to do disconnection
	if (!anaren_control_stay_connected && !anaren_control_indication_sent)
	{
		bleprofile_StartConnIdleTimer(bleprofile_p_cfg->con_idle_timeout, bleprofile_appTimerCb);
		return;
	}

	// We are done with initial settings, and need to stay connected.  It is a good
	// time to change the pace of master polls to save power.
	bleprofile_SendConnParamUpdateReq(BLE_INTERVAL_MIN, BLE_INTERVAL_MAX, BLE_SLAVE_LATENCY, BLE_CONNECTION_TIMEOUT);
}

//
// Return the callback value as a notification to the controller
//
void anaren_control_send_message(void)
{
	BLEPROFILE_DB_PDU db_pdu;

	// If client has not registered for indication or notification, do not need to do anything
	if (anaren_control_hostinfo.characteristic_client_configuration == 0)
		return;

	// Read value of the characteristic to send from the GATT DB.
	bleprofile_ReadHandle(ATMOSPHERE_NOTIFY_HANDLE - 1, &db_pdu);

	if (anaren_control_hostinfo.characteristic_client_configuration & CCC_NOTIFICATION)
	{
		bleprofile_sendNotification(ATMOSPHERE_NOTIFY_HANDLE - 1, (UINT8*)db_pdu.pdu, db_pdu.len);
	}
	else
	{
		if (!anaren_control_indication_sent)
		{
			anaren_control_indication_sent = TRUE;
			bleprofile_sendIndication(ATMOSPHERE_NOTIFY_HANDLE - 1, (UINT8*)db_pdu.pdu, db_pdu.len, anaren_control_indication_cfm);
		}
	}
}

void anaren_control_interrupt_handler(UINT8 value)
{
}

// process indication confirmation.  if client wanted us to use indication instead of notifications
// we have to wait for confirmation after every message sent.  For example if user pushed button
// twice very fast we will send first message, wait for confirmation, send second message, wait
// for confirmation and if configured start idle timer only after that.
void anaren_control_indication_cfm(void)
{
}

// following should go to bleprofile.c

// Start connection idle timer if it is not running
void bleprofile_StartConnIdleTimer(UINT8 timeout, BLEAPP_TIMER_CB cb)
{
	if (emconinfo_getAppTimerId() < 0)
	{
		emconinfo_setIdleConnTimeout(timeout);
		blecm_startConnIdleTimer(cb);
	}
}

// Stop connection idle timer if it is running
void bleprofile_StopConnIdleTimer(void)
{
	if (emconinfo_getAppTimerId() >= 0)
	{
		blecm_stopConnIdleTimer();
		emconinfo_setAppTimerId(-1);
	}
}

// Send request to client to update connection parameters
void bleprofile_SendConnParamUpdateReq(UINT16 minInterval, UINT16 maxInterval, UINT16 slaveLatency, UINT16 timeout)
{
	if (minInterval > maxInterval)
		return;

	lel2cap_sendConnParamUpdateReq(minInterval, maxInterval, slaveLatency, timeout);
}

