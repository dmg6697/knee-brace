 
int __wrap_abs (int i)
{
	return i < 0 ? -i : i;
}
