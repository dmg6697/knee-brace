#include "cfa.h"
#include "types.h"

void AIR_I2C_Init()
{
	return;
}

/**
 *  AIR_I2C_ComboRead
 *
 *    @param slaveAddr
 *    @param writeBytes
 *    @param numWriteBytes
 *    @param readBytes
 *    @param numReadBytes
 */
void AIR_I2C_ComboRead(unsigned char slaveAddr, unsigned char* writeBytes, unsigned int numWriteBytes, unsigned char* readBytes, unsigned int numReadBytes)
{
//	i2cm_comboRead(readBytes, numReadBytes, writeBytes, numWriteBytes, slaveAddr<<1);
	cfa_bsc_OpExtended(readBytes, numReadBytes, writeBytes, numWriteBytes, slaveAddr << 1, 0);
}

/**
 *  AIR_I2C_Write
 *
 *    @param slaveAddr
 *    @param writeBytes
 *    @param numBytes
 */
void AIR_I2C_Write(unsigned char slaveAddr, unsigned char* writeBytes, unsigned int numBytes)
{
//	i2cm_write(writeBytes, numBytes, slaveAddr<<1);

	int offset = 0;

	while (numBytes >= 16)
	{
		cfa_bsc_OpExtended(writeBytes + (offset * 16), 16, NULL, 0, slaveAddr << 1, 1);
		numBytes = numBytes - 16;
		offset++;
	}

	if (numBytes > 0)
	{
		cfa_bsc_OpExtended(writeBytes + (offset * 16), numBytes, NULL, 0, slaveAddr << 1, 1);
	}
}

/**
 *  AIR_I2C_Read
 *
 *    @param slaveAddr
 *    @param readBytes
 *    @param numBytes
 */
void AIR_I2C_Read(unsigned char slaveAddr, unsigned char *readBytes, unsigned int numBytes)
{
//      cfa_bsc_OpExtended(readBytes, numBytes, NULL, 0, slaveAddr<<1, 0);

	int offset = 0;

	while (numBytes >= 16)
	{
		cfa_bsc_OpExtended(readBytes + (offset * 16), 16, NULL, 0, slaveAddr << 1, 0);
		numBytes = numBytes - 16;
		offset++;
	}

	if (numBytes > 0)
	{
		cfa_bsc_OpExtended(readBytes + (offset * 16), numBytes, NULL, 0, slaveAddr << 1, 0);
	}
}