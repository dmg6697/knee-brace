
//Dynamically generated header, do not edit the following.
#ifndef CALLBACKS_H
#define CALLBACKS_H

#include "pin_mapping.h"
#include "bleprofile.h"
#include "bleapp.h"
#include "generic/generic.h"
#include "atmosphere/atmosphere.h"
#include "string.h"
#include "stdio.h"
#include "platform.h"
#include "spar_utils.h"
#include "power/power.h"
#include "gatt/gatt.h"
#include "json/json.h"
#include "gpio/gpio.h"
#include "uart/uart.h"
#include "i2c/i2c.h"
#include "buzzer/buzzer.h"
#include "ble/ble.h"
#include "fp_math/fp_math.h"

#define atof JSON_ReadFloat

void setup();

void interval();

void connected();

void disconnected();

#define ID_ADCReadPot 0x18
int ADCReadPot();
#define ID_GPIOLEDEnable 0x1a
void GPIOLEDEnable(bool data);
#define ID_GPIOPinEnable 0x1c
void GPIOPinEnable(bool data);
#endif
