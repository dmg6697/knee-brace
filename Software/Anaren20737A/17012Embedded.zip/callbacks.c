#include "callbacks.h"

//END


void interval() {

}


void connected() {

}


void disconnected() {

}


void setup() {
	AIR_GPIO_Init();
	AIR_POWER_Init();
	AIR_UART_Init();
	AIR_I2C_Init();
	AIR_SPI_Init();
	AIR_POWER_SetMode(AIR_POWER_NOSLEEP);
}


int ADCReadPot()
{

	
	AIR_ADC_Enable(11);
	
	return AIR_ADC_Read(11);
	
}

void GPIOLEDEnable(bool data)
{

	
	if(AIR_GPIO_GetMode(0) != AIR_GPIO_OUTPUT_PUSH_PULL)
	{
		AIR_GPIO_SetMode(0, AIR_GPIO_OUTPUT_PUSH_PULL);
	}
	
	AIR_GPIO_Write(0, data);
	
	return;
	
}

void GPIOPinEnable(bool data)
{

	
	if(AIR_GPIO_GetMode(15) != AIR_GPIO_OUTPUT_PUSH_PULL)
	{
		AIR_GPIO_SetMode(15, AIR_GPIO_OUTPUT_PUSH_PULL);
	}
	
	AIR_GPIO_Write(15, data);
	
	return;
	
}

