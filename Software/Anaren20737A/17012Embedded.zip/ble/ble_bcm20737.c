#include "ble.h"
#include "bleprofile.h"
#include "bleapp.h"
#include "emconinfo.h"
#include "stdio.h"
#include "string.h"
#include "spar_utils.h" // sprintf, J-Link debug
#include "additional_advertisement_control.h"


#define HCIULP_ADV_CONNECTABLE_UNDIRECT_EVENT 0x00
#define HCIULP_ADV_CONNECTABLE_DIRECT_EVENT 0x01
#define HCIULP_ADV_DISCOVERABLE_EVENT 0x02
#define HCIULP_ADV_NONCONNECTABLE_EVENT 0x03

#define     HCIULP_ADV_NONCONNECTABLE_EVENT                                 0x03
#define     HCIULP_ADV_CHANNEL_37                                           0x01
#define     HCIULP_ADV_CHANNEL_38                                           0x02
#define     HCIULP_ADV_CHANNEL_39                                           0x04

#define     HCIULP_ADV_CHANNEL_MAP_MASK                                     (HCIULP_ADV_CHANNEL_37 | HCIULP_ADV_CHANNEL_38 | HCIULP_ADV_CHANNEL_39)

#define     HCIULP_PUBLIC_ADDRESS                                           0x00

#define     HCIULP_ADV_FILTER_POLICY_WHITE_LIST_NOT_USED                    0x00    // white list not used

static bool ble_discoverable = false;

static UINT8 ble_oob_tk[LESMP_MAX_KEY_SIZE];

static UINT8 ble_passkey[LESMP_MAX_KEY_SIZE];

static UINT8 ble_remote_addr[] = { 0, 0, 0, 0, 0, 0 };

void AIR_BLE_Init()
{
}

void AIR_BLE_SetDiscoverable(bool discoverable)
{
	memset(ble_remote_addr, 0, 6);

	ble_discoverable = discoverable;

	if (discoverable)
	{
		blecm_startAdv(
			HCIULP_ADV_CONNECTABLE_UNDIRECT_EVENT,                // non-connectable undirected advertisement
			160,                                            // adv interval 100 msec
			HCIULP_ADV_CHANNEL_MAP_MASK,                    // all channels
			HCIULP_PUBLIC_ADDRESS,                          // int advAdrType,
			HCIULP_ADV_FILTER_POLICY_WHITE_LIST_NOT_USED,   // int advFilterPolicy,
			HCIULP_PUBLIC_ADDRESS,                          // int initiatorAdrType,
			NULL);
	}

	else
	{
		blecm_setAdvEnable(false);
	}
}

void AIR_BLE_SetDirectedDiscoverable(bool discoverable, unsigned char *address)
{
	memcpy(ble_remote_addr, address, 6);

	ble_discoverable = discoverable;

	if (discoverable)
	{
		blecm_startAdv(
			HIGH_DIRECTED_DISCOVERABLE,                // non-connectable undirected advertisement
			160,                                            // adv interval 100 msec
			HCIULP_ADV_CHANNEL_MAP_MASK,                    // all channels
			HCIULP_PUBLIC_ADDRESS,                          // int advAdrType,
			HCIULP_ADV_FILTER_POLICY_WHITE_LIST_NOT_USED,   // int advFilterPolicy,
			HCIULP_PUBLIC_ADDRESS,                          // int initiatorAdrType,
			NULL);
	}

	else
	{
		blecm_setAdvEnable(false);
	}
}

AIR_BLE_DiscoveryMode AIR_BLE_GetDiscoverable()
{
	return ble_discoverable;
}

void AIR_BLE_SetPairingMode(AIR_BLE_PairingMode mode)
{
//      lesmp_clearJustWorksNotPermitted();
//      lesmp_clearOOBNotPermitted();
//      lesmp_clearPairingNotPermitted();
//      lesmp_clearPasskeyEntryNotPermitted();
//
//      switch(mode)
//      {
//              case AIR_BLE_PAIRING_NONE:
//                      lesmp_setPairingParam(
//                              LESMP_IO_CAP_DISP_ONLY,
//                              LESMP_OOB_AUTH_DATA_NOT_PRESENT,
//                              LESMP_AUTH_FLAG_NO_BONDING,
//                              LESMP_MAX_KEY_SIZE,
//                              0x00,
//                              0x00);
//
//                      lesmp_JustWorksNotPermitted();
//                      lesmp_OOBNotPermitted();
//                      lesmp_PairingNotPermitted();
//                      lesmp_PasskeyEntryNotPermitted();
//                      break;
//
//              case AIR_BLE_PAIRING_OPEN:
//                      lesmp_setPairingParam(
//                              LESMP_IO_CAP_DISP_ONLY,
//                              LESMP_OOB_AUTH_DATA_NOT_PRESENT,
//                              LESMP_AUTH_FLAG_NO_BONDING,
//                              LESMP_MAX_KEY_SIZE,
//                              0x00,
//                              0x00);
//
//                      lesmp_OOBNotPermitted();
//                      lesmp_PairingNotPermitted();
//                      lesmp_PasskeyEntryNotPermitted();
//                      break;
//
//              case AIR_BLE_PAIRING_OOB:
//                      lesmp_setPairingParam(
//                                      LESMP_IO_CAP_DISP_ONLY,
//                                      LESMP_OOB_AUTH_DATA_FROM_REMOTE_PRESENT, // OOBDataFlag,
//                                      LESMP_AUTH_FLAG_BONDING,                // AuthReq,
//                                      LESMP_MAX_KEY_SIZE,             // MaxEncKeySize,
//                                      // InitiatorKeyDistrib,
//                                      LESMP_KEY_DISTRIBUTION_ENC_KEY
//                                      | LESMP_KEY_DISTRIBUTION_ID_KEY
//                                      | LESMP_KEY_DISTRIBUTION_SIGN_KEY,
//                                      // ResponderKeyDistrib
//                                      LESMP_KEY_DISTRIBUTION_ENC_KEY
//                                      | LESMP_KEY_DISTRIBUTION_ID_KEY
//                                      | LESMP_KEY_DISTRIBUTION_SIGN_KEY
//                              );
//
//                      lesmp_setSMPOOBdata((UINT8*)ble_oob_tk, LESMP_MAX_KEY_SIZE);
//                      lesmp_setJustWorksNotPermitted();
//                      lesmp_setPasskeyEntryNotPermitted();
//                      break;
//
//              case AIR_BLE_PAIRING_PASSKEY:
//                      lesmp_setPairingParam(
//                              LESMP_IO_CAP_DISP_ONLY,
//                              LESMP_OOB_AUTH_DATA_NOT_PRESENT, // OOBDataFlag,
//                              LESMP_AUTH_FLAG_BONDING                 // AuthReq,
//                              | LESMP_AUTH_REQ_FLAG_MITM,
//                              LESMP_MAX_KEY_SIZE,             // MaxEncKeySize,
//                              // InitiatorKeyDistrib,
//                              LESMP_KEY_DISTRIBUTION_ENC_KEY
//                              | LESMP_KEY_DISTRIBUTION_ID_KEY
//                              | LESMP_KEY_DISTRIBUTION_SIGN_KEY,
//                              // ResponderKeyDistrib
//                              LESMP_KEY_DISTRIBUTION_ENC_KEY
//                              | LESMP_KEY_DISTRIBUTION_ID_KEY
//                              | LESMP_KEY_DISTRIBUTION_SIGN_KEY
//                      );
//
//                      lesmp_setSMPassKey((UINT8*)ble_passkey, LESMP_MAX_KEY_SIZE);
//                      lesmp_setJustWorksNotPermitted();
//                      break;
//
//              default:
//                      break;
//      }
}

void AIR_BLE_SetPassKey(unsigned char *key, unsigned int length)
{
	if (key == NULL || length > LESMP_MAX_KEY_SIZE)
	{
		return;
	}

	unsigned int i;

	for (i = 0; i < length; i++)
	{
		ble_passkey[i] = key[i];
	}

	for (i; i < LESMP_MAX_KEY_SIZE; i++)
	{
		ble_passkey[i] = 0x00;
	}

	lesmp_setSMPassKey((UINT8*)ble_passkey, LESMP_MAX_KEY_SIZE);
}

void AIR_BLE_SetOOBTk(unsigned char *tk, unsigned int length)
{
	if (tk == NULL || length > LESMP_MAX_KEY_SIZE)
	{
		return;
	}

	unsigned int i;

	for (i = 0; i < length; i++)
	{
		ble_oob_tk[i] = tk[i];
	}

	for (i; i < LESMP_MAX_KEY_SIZE; i++)
	{
		ble_oob_tk[i] = 0x00;
	}

	lesmp_setSMPOOBdata((UINT8*)ble_oob_tk, LESMP_MAX_KEY_SIZE);
}

void AIR_BLE_GetMacAddress(unsigned char *addressBuf, unsigned int length)
{
	if (length < 18)
	{
		return;
	}

	unsigned char *macAddress = emconinfo_getAddr();

	sprintf(addressBuf, "%02X:%02X:%02X:%02X:%02X:%02X",
			macAddress[5],
			macAddress[4],
			macAddress[3],
			macAddress[2],
			macAddress[1],
			macAddress[0]);

	return;
}

void AIR_BLE_SetAdvertisingName(char *name)
{
	if(strlen(name) + 1 < LOCAL_NAME_LEN_MAX)
	{
		memcpy(bleprofile_p_cfg->local_name, name, strlen(name) + 1);
	}
}