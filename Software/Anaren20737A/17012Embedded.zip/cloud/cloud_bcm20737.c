#include "cloud.h"
#include "bleprofile.h"
#include "bleapp.h"
#include "../gatt/gatt.h"
#include "../gpio/gpio.h"
#include "../air_gatt_defines.h"
#include "../nvram/nvram.h"
#include "../uart/uart.h"

void CLOUD_SetCredentialGatt(CLOUD_Registration *registration)
{
	unsigned int length = 64;

	BLEPROFILE_DB_PDU* long_db_pdu = cfa_mm_Alloc(sizeof(UINT8) + sizeof(UINT8) + length);

	unsigned int i = 0;

	for (i = 0; i < length; i++)
	{
		if (registration->uuid[i] == 0)
		{
			long_db_pdu->pdu[i] = '|';
			break;
		}

		long_db_pdu->pdu[i] = registration->uuid[i];
	}

	i = i + 1;

	unsigned int j = 0;

	for (j = 0; i < length; j++, i++)
	{
		if (registration->token[j] == 0)
		{
			long_db_pdu->pdu[i] = '\0';
			break;
		}

		long_db_pdu->pdu[i] = registration->token[j];
	}

	long_db_pdu->len = i + 1;

	if (i + 1 > 23)
	{
		bleprofile_WriteHandleData(ATMOSPHERE_GATT_CLOUD_CREDENTIALS_HANDLE, long_db_pdu, sizeof(UINT8) + sizeof(UINT8) + i + 1);
	}

	else
	{
		bleprofile_WriteHandle(ATMOSPHERE_GATT_CLOUD_CREDENTIALS_HANDLE, long_db_pdu);
	}

	cfa_mm_Free(long_db_pdu);
}

cloud_err_t CLOUD_Init()
{
	CLOUD_Registration reg;

	CLOUD_LoadRegistration(&reg);
	
	return CLOUD_OK;
}

//This will set the cloud credential gatt characteritic to send a registration request.
//For BLE we need to change our advertising data to let a gateway know we need to send data out to the cloud.
cloud_err_t CLOUD_RegisterThing(char *name, char *owner, char *password, char *meta, char *postProvisionToken)
{
	return CLOUD_OK;
}

//This will save a registration to NVRAM, for the BCM20737 and most BLE devices this will also set the cloud credential characteritic as well.
cloud_err_t CLOUD_SaveRegistration(CLOUD_Registration *registration)
{
	
	AIR_NVRAM_Write(0x6e, (unsigned char*)registration, sizeof(CLOUD_Registration));

	CLOUD_SetCredentialGatt(registration);

	return CLOUD_OK;
}

//This will load a registration from NVRAM and then set the GATT crednetial characteritic.
cloud_err_t CLOUD_LoadRegistration(CLOUD_Registration *registration)
{
	AIR_NVRAM_Read(0x6e, (unsigned char*)registration, sizeof(CLOUD_Registration));

	CLOUD_SetCredentialGatt(registration);

	return CLOUD_OK;
}
