#include "generic.h"
#include "cfa.h"
#include "types.h"

extern void bleapputils_delayUs(UINT32 delay);

void AIR_GENERIC_Init()
{

}

void AIR_GENERIC_UDelay(unsigned int microSeconds)
{
	bleapputils_delayUs(microSeconds);
}
