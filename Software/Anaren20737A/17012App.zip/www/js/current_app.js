
function MyApp(parent) {

	var airMe = this;
	
	this.parent = parent;

	this.parent.buildUuid = "baa17569-4684-455f-a036-f82cf20432e1";
	this.parent.projectName = "17012";
	this.parent.cloudUrl = "atmosphere.anaren.com:1337";
		
	this.parent.cloudCredentialsOnEmbedded = true;
		
	this.parent.serviceUUID = "3a07d6ff-f29f-4bd8-978a-fd518c3c5f8e";
	this.parent.notifyUUID = "3a07d6ff-f29f-4bd8-978a-fd518c3c5f8f";
		
	this.parent.localName = "P17012";
	this.parent.embeddedChains = {"GPIOLEDEnable": [], "GPIOPinEnable": [], "ADCReadPot": []};

	this.element_Slider14_mouseReleased = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Slider14.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.runEvery = " + "value", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Slider14\" ]---X--->[ \"ReadADC\" ] " + err.toString());
				}
				
				return;
			}
				
			try {
				eval("targetValues.runIn = " + "value", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Slider14\" ]---X--->[ \"ReadADC\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_ReadADC.run(clone(targetValues.runIn),clone(targetValues.runEvery));
					
			//airMe.parent.debugLog("Connection Event: [ \"Slider14\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"ReadADC\" ]");
		})();

	};

	this.element_Condition15_conditionTrue = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.runEvery = " + "1000", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"ReadADC\" ] " + err.toString());
				}
				
				return;
			}
				
			try {
				eval("targetValues.runIn = " + "2000", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"ReadADC\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_ReadADC.run(clone(targetValues.runIn),clone(targetValues.runEvery));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"ReadADC\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "true", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"GPIOLEDEnable\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_GPIOLEDEnable.execute(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"GPIOLEDEnable\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.visible = " + "true", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"Slider14\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_Slider14.setVisible(clone(targetValues.visible));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"Slider14\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "1000", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"Slider14\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_Slider14.setValue(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"Slider14\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "true", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"GPIOPinEnable\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_GPIOPinEnable.execute(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"GPIOPinEnable\" ]");
		})();

	};

	this.element_Condition15_conditionFalse = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			airMe.element_ReadADC.pause();
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"ReadADC\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "false", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"GPIOLEDEnable\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_GPIOLEDEnable.execute(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"GPIOLEDEnable\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.visible = " + "false", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"Slider14\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_Slider14.setVisible(clone(targetValues.visible));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"Slider14\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_Condition15.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "false", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"Condition15\" ]---X--->[ \"GPIOPinEnable\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_GPIOPinEnable.execute(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"Condition15\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"GPIOPinEnable\" ]");
		})();

	};

	this.element_ReadADC_task = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue;
			try {
				eval("targetValues.value = " + "undefined", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"ReadADC\" ]---X--->[ \"ADCReadPot\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_ADCReadPot.execute(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"ReadADC\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"ADCReadPot\" ]");
		})();

	};

	this.element_ADCReadPot_valueReturned = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_ADCReadPot.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "value", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"ADCReadPot\" ]---X--->[ \"ADCValue\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_ADCValue.setValue(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"ADCReadPot\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"ADCValue\" ]");
		})();

		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_ADCReadPot.getValue();
			var value = sourceValue;
			atmoLocalValues["value"] = sourceValue;
			try {
				eval("targetValues.value = " + "\"\\n\" + value", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"ADCReadPot\" ]---X--->[ \"Label19\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_Label19.appendValue(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"ADCReadPot\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"Label19\" ]");
		})();

	};

	this.element_BtnClear_mousePressed = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue;
			try {
				eval("targetValues.value = " + "\"\"", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"BtnClear\" ]---X--->[ \"Label19\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_Label19.setValue(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"BtnClear\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"Label19\" ]");
		})();

	};

	this.element_CheckEnable_switched = function(e) {
		(function(){
			var targetValues = {};
			var atmoLocalValues = {};
			atmoLocalValues["targetValues"] = {};
			var sourceValue =  airMe.element_CheckEnable.getValue();
			var state = sourceValue;
			atmoLocalValues["state"] = sourceValue;
			try {
				eval("targetValues.value = " + "state", atmoLocalValues);
				
				if(typeof atmoLocalValues === "object" && atmoLocalValues.targetValues !== undefined && Object.keys(atmoLocalValues.targetValues).length !== 0) {
					targetValues = atmoLocalValues.targetValues;
				}
			}
			
			catch(err) {
				if(airMe.parent.debugLog !== undefined) {
					airMe.parent.debugLog("Connector Error: [ \"CheckEnable\" ]---X--->[ \"Condition15\" ] " + err.toString());
				}
				
				return;
			}
				
			airMe.element_Condition15.check(clone(targetValues.value));
					
			//airMe.parent.debugLog("Connection Event: [ \"CheckEnable\" ]---(" + JSON.stringify(targetValues) + ")--->[ \"Condition15\" ]");
		})();

	};

		this.layouts = {"Default": {"devicename": ".*", "elements": {"Slider14": {"y": 7, "x": 7, "height": 86, "width": 106}, "ADCValue": {"y": 7, "x": 7, "height": 46, "width": 146}, "ImagePan17": {"y": 7, "x": 7, "height": 76, "width": 76}, "TextField7": {"y": 7, "x": 7, "height": 34, "width": 114}, "Slider11": {"y": 7, "x": 7, "height": 86, "width": 106}, "ADCReading": {"y": 7, "x": 7, "height": 46, "width": 146}, "TextField9": {"y": 7, "x": 7, "height": 34, "width": 114}, "BtnClear": {"y": 7, "x": 7, "height": 46, "width": 146}, "BtnConnect": {"y": 7, "x": 7, "height": 46, "width": 146}, "Checkbox9": {"y": 7, "x": 7, "height": 34, "width": 114}, "Label19": {"y": 7, "x": 7, "height": 46, "width": 146}, "BtnEnable": {"y": 7, "x": 7, "height": 46, "width": 146}, "CheckEnable": {"y": 7, "x": 7, "height": 34, "width": 114}, "BtnStatus": {"y": 7, "x": 7, "height": 46, "width": 146}, "Label12": {"y": 7, "x": 7, "height": 46, "width": 146}, "Label10": {"y": 7, "x": 7, "height": 46, "width": 146}, "TextField16": {"y": 7, "x": 7, "height": 34, "width": 114}}, "orientation": "portrait", "platform": "", "height": 1024, "width": 768, "version": ".*", "name": "Default (768x1024)"}, "GalaxyS7": {"devicename": ".*", "elements": {"Slider14": {"y": 586, "x": 106, "height": 56, "width": 235}, "ADCValue": {"y": 9, "x": 98, "height": 25, "width": 142}, "ADCReading": {"y": 13, "x": 13, "height": 18, "width": 70}, "BtnClear": {"y": 476, "x": 205, "height": 46, "width": 146}, "Label19": {"y": 49, "x": 11, "height": 401, "width": 337}, "CheckEnable": {"y": 594, "x": 9, "height": 34, "width": 66}}, "orientation": "portrait", "platform": "Android", "height": 640, "width": 360, "version": ".*", "name": "Samsung Galaxy S7"}};
			
	this.initialize = function() {

			this.currentLayout = this.parent.layoutSelector(this.layouts);
			
			
			this.element_Slider14 = new SliderElement(this.parent, "Slider14");
			
			this.element_Slider14.setVisible(true);
			this.element_Slider14.setEnabled(true);
			this.element_Slider14.setShowScale(false);
			this.element_Slider14.setShowTitle(true);
			this.element_Slider14.setMinValue(100);
			this.element_Slider14.setMaxValue(1000);
			this.element_Slider14.setValue(0);
			this.element_Slider14.setIntervals([0, 450, 450]);
			this.element_Slider14.setScaleStep(100);
			this.element_Slider14.setOrientation("Horizontal");

			if(this.element_Slider14_onTrigger)
				this.element_Slider14.onTrigger = this.element_Slider14_onTrigger;
			
			if(this.element_Slider14_changed)
				this.element_Slider14.changed = this.element_Slider14_changed;
			
			if(this.element_Slider14_valueSet)
				this.element_Slider14.valueSet = this.element_Slider14_valueSet;
				
			if(this.element_Slider14_mousePressed)
				this.element_Slider14.mousePressed = this.element_Slider14_mousePressed;
				
			if(this.element_Slider14_mouseClicked)
				this.element_Slider14.mouseClicked = this.element_Slider14_mouseClicked;
			
			if(this.element_Slider14_mouseReleased)
				this.element_Slider14.mouseReleased = this.element_Slider14_mouseReleased;
			
			if(this.element_Slider14_mouseEntered)
				this.element_Slider14.mouseEntered = this.element_Slider14_mouseEntered;
			
			if(this.element_Slider14_mouseMoved)
				this.element_Slider14.mouseMoved = this.element_Slider14_mouseMoved;
			
			if(this.element_Slider14_mouseExited)
				this.element_Slider14.mouseExited = this.element_Slider14_mouseExited;
			
			this.element_Slider14.setBounds(this.layouts[this.currentLayout]["elements"]["Slider14"].x, 
							this.layouts[this.currentLayout]["elements"]["Slider14"].y, 
							this.layouts[this.currentLayout]["elements"]["Slider14"].width, 
							this.layouts[this.currentLayout]["elements"]["Slider14"].height);
							
		
			this.element_ADCValue = new LabelElement(this.parent, "ADCValue");
			
			this.element_ADCValue.setValue("");
			this.element_ADCValue.setVisible(true);
			this.element_ADCValue.setEnabled(true);
			this.element_ADCValue.setColor("Black");
			this.element_ADCValue.setFont("14px Arial");
			
			if(this.element_ADCValue_onTrigger !== undefined)
				this.element_ADCValue.onTrigger = this.element_ADCValue_onTrigger;
			
			if(this.element_ADCValue_mousePressed !== undefined)
				this.element_ADCValue.mousePressed = this.element_ADCValue_mousePressed;
				
			if(this.element_ADCValue_mouseClicked !== undefined)
				this.element_ADCValue.mouseClicked = this.element_ADCValue_mouseClicked;
			
			if(this.element_ADCValue_mouseReleased !== undefined)
				this.element_ADCValue.mouseReleased = this.element_ADCValue_mouseReleased;
			
			if(this.element_ADCValue_mouseEntered !== undefined)
				this.element_ADCValue.mouseEntered = this.element_ADCValue_mouseEntered;
			
			if(this.element_ADCValue_mouseMoved !== undefined)
				this.element_ADCValue.mouseMoved = this.element_ADCValue_mouseMoved;
			
			if(this.element_ADCValue_mouseExited !== undefined)
				this.element_ADCValue.mouseExited = this.element_ADCValue_mouseExited;
			
			this.element_ADCValue.setBounds(this.layouts[this.currentLayout]["elements"]["ADCValue"].x, 
								this.layouts[this.currentLayout]["elements"]["ADCValue"].y, 
								this.layouts[this.currentLayout]["elements"]["ADCValue"].width, 
								this.layouts[this.currentLayout]["elements"]["ADCValue"].height);
							
		
			this.element_Condition15 = new ConditionElement(this.parent);
			
			if(this.element_Condition15_onTrigger)
				this.element_Condition15.onTrigger = this.element_Condition15_onTrigger;
		
			if(this.element_Condition15_conditionTrue)
				this.element_Condition15.conditionTrue = this.element_Condition15_conditionTrue;
		
			if(this.element_Condition15_conditionFalse)
				this.element_Condition15.conditionFalse = this.element_Condition15_conditionFalse;
		
			this.element_ReadADC = new zebra.util.task(function(c){
				if(airMe.element_ReadADC_task)
					airMe.element_ReadADC_task();
			});
			
			this.element_ReadADC.element_ReadADC_task = this.element_ReadADC_task;

			this.element_ReadADC.trigger = function() {
				if(this.onTrigger)
					this.onTrigger();
			}
			
			if(this.element_ReadADC_onTrigger)
				this.element_ReadADC.onTrigger = this.element_ReadADC_onTrigger;
			
			this.element_ReadADC.run(2000, 2000);
			
		
			this.element_ReadADC.pause();
			
			this.element_ADCReading = new LabelElement(this.parent, "ADCReading");
			
			this.element_ADCReading.setValue("ADC Value");
			this.element_ADCReading.setVisible(true);
			this.element_ADCReading.setEnabled(true);
			this.element_ADCReading.setColor("Black");
			this.element_ADCReading.setFont("14px Arial");
			
			if(this.element_ADCReading_onTrigger !== undefined)
				this.element_ADCReading.onTrigger = this.element_ADCReading_onTrigger;
			
			if(this.element_ADCReading_mousePressed !== undefined)
				this.element_ADCReading.mousePressed = this.element_ADCReading_mousePressed;
				
			if(this.element_ADCReading_mouseClicked !== undefined)
				this.element_ADCReading.mouseClicked = this.element_ADCReading_mouseClicked;
			
			if(this.element_ADCReading_mouseReleased !== undefined)
				this.element_ADCReading.mouseReleased = this.element_ADCReading_mouseReleased;
			
			if(this.element_ADCReading_mouseEntered !== undefined)
				this.element_ADCReading.mouseEntered = this.element_ADCReading_mouseEntered;
			
			if(this.element_ADCReading_mouseMoved !== undefined)
				this.element_ADCReading.mouseMoved = this.element_ADCReading_mouseMoved;
			
			if(this.element_ADCReading_mouseExited !== undefined)
				this.element_ADCReading.mouseExited = this.element_ADCReading_mouseExited;
			
			this.element_ADCReading.setBounds(this.layouts[this.currentLayout]["elements"]["ADCReading"].x, 
								this.layouts[this.currentLayout]["elements"]["ADCReading"].y, 
								this.layouts[this.currentLayout]["elements"]["ADCReading"].width, 
								this.layouts[this.currentLayout]["elements"]["ADCReading"].height);
							
		
			this.element_ADCReadPot = new FunctionElement(this.parent, "ADCReadPot", 24, "3a07d6ff-f29f-4bd8-978a-fd518c3c5f90", "int", "void");
				
			if(this.element_ADCReadPot_onTrigger)
				this.element_ADCReadPot.onTrigger = this.element_ADCReadPot_onTrigger;
			
			if(this.element_ADCReadPot_valueReturned)
				this.element_ADCReadPot.valueReturned = this.element_ADCReadPot_valueReturned;
				
			if(this.element_ADCReadPot_notified)
				this.element_ADCReadPot.notified = this.element_ADCReadPot_notified;
		
			this.element_BtnClear = new ButtonElement(this.parent, "BtnClear");
			
			this.element_BtnClear.setLabel("Clear");
			this.element_BtnClear.setVisible(true);
			this.element_BtnClear.setEnabled(true);
		
			this.element_BtnClear.setBorder("plain");

			if(this.element_BtnClear_onTrigger !== undefined)
				this.element_BtnClear.onTrigger = this.element_BtnClear_onTrigger;
			
			if(this.element_BtnClear_mousePressed !== undefined)
				this.element_BtnClear.mousePressed = this.element_BtnClear_mousePressed;
				
			if(this.element_BtnClear_mouseClicked !== undefined)
				this.element_BtnClear.mouseClicked = this.element_BtnClear_mouseClicked;
			
			if(this.element_BtnClear_mouseReleased !== undefined)
				this.element_BtnClear.mouseReleased = this.element_BtnClear_mouseReleased;
			
			if(this.element_BtnClear_mouseEntered !== undefined)
				this.element_BtnClear.mouseEntered = this.element_BtnClear_mouseEntered;
			
			if(this.element_BtnClear_mouseMoved !== undefined)
				this.element_BtnClear.mouseMoved = this.element_BtnClear_mouseMoved;
			
			if(this.element_BtnClear_mouseExited !== undefined)
				this.element_BtnClear.mouseExited = this.element_BtnClear_mouseExited;
			
			this.element_BtnClear.setBounds(this.layouts[this.currentLayout]["elements"]["BtnClear"].x, 
							this.layouts[this.currentLayout]["elements"]["BtnClear"].y, 
							this.layouts[this.currentLayout]["elements"]["BtnClear"].width, 
							this.layouts[this.currentLayout]["elements"]["BtnClear"].height);
			
		
			this.element_GPIOLEDEnable = new FunctionElement(this.parent, "GPIOLEDEnable", 26, "3a07d6ff-f29f-4bd8-978a-fd518c3c5f91", "void", "bool");
				
			if(this.element_GPIOLEDEnable_onTrigger)
				this.element_GPIOLEDEnable.onTrigger = this.element_GPIOLEDEnable_onTrigger;
			
			if(this.element_GPIOLEDEnable_valueReturned)
				this.element_GPIOLEDEnable.valueReturned = this.element_GPIOLEDEnable_valueReturned;
				
			if(this.element_GPIOLEDEnable_notified)
				this.element_GPIOLEDEnable.notified = this.element_GPIOLEDEnable_notified;
		
			this.element_GPIOPinEnable = new FunctionElement(this.parent, "GPIOPinEnable", 28, "3a07d6ff-f29f-4bd8-978a-fd518c3c5f92", "void", "bool");
				
			if(this.element_GPIOPinEnable_onTrigger)
				this.element_GPIOPinEnable.onTrigger = this.element_GPIOPinEnable_onTrigger;
			
			if(this.element_GPIOPinEnable_valueReturned)
				this.element_GPIOPinEnable.valueReturned = this.element_GPIOPinEnable_valueReturned;
				
			if(this.element_GPIOPinEnable_notified)
				this.element_GPIOPinEnable.notified = this.element_GPIOPinEnable_notified;
		
			this.element_Label19 = new LabelElement(this.parent, "Label19");
			
			this.element_Label19.setValue("");
			this.element_Label19.setVisible(true);
			this.element_Label19.setEnabled(true);
			this.element_Label19.setColor("Black");
			this.element_Label19.setFont("14px Arial");
			
			if(this.element_Label19_onTrigger !== undefined)
				this.element_Label19.onTrigger = this.element_Label19_onTrigger;
			
			if(this.element_Label19_mousePressed !== undefined)
				this.element_Label19.mousePressed = this.element_Label19_mousePressed;
				
			if(this.element_Label19_mouseClicked !== undefined)
				this.element_Label19.mouseClicked = this.element_Label19_mouseClicked;
			
			if(this.element_Label19_mouseReleased !== undefined)
				this.element_Label19.mouseReleased = this.element_Label19_mouseReleased;
			
			if(this.element_Label19_mouseEntered !== undefined)
				this.element_Label19.mouseEntered = this.element_Label19_mouseEntered;
			
			if(this.element_Label19_mouseMoved !== undefined)
				this.element_Label19.mouseMoved = this.element_Label19_mouseMoved;
			
			if(this.element_Label19_mouseExited !== undefined)
				this.element_Label19.mouseExited = this.element_Label19_mouseExited;
			
			this.element_Label19.setBounds(this.layouts[this.currentLayout]["elements"]["Label19"].x, 
								this.layouts[this.currentLayout]["elements"]["Label19"].y, 
								this.layouts[this.currentLayout]["elements"]["Label19"].width, 
								this.layouts[this.currentLayout]["elements"]["Label19"].height);
							
		
			this.element_CheckEnable = new CheckboxElement(this.parent, "CheckEnable");
			
			this.element_CheckEnable.setLabel("Enable");
			this.element_CheckEnable.setVisible(true);
			this.element_CheckEnable.setEnabled(true);
			this.element_CheckEnable.setValue(false);

			if(this.element_CheckEnable_onTrigger)
				this.element_CheckEnable.onTrigger = this.element_CheckEnable_onTrigger;
			
			if(this.element_CheckEnable_switched)
				this.element_CheckEnable.switched = this.element_CheckEnable_switched;
			
			this.element_CheckEnable.setBounds(this.layouts[this.currentLayout]["elements"]["CheckEnable"].x, 
							this.layouts[this.currentLayout]["elements"]["CheckEnable"].y, 
							this.layouts[this.currentLayout]["elements"]["CheckEnable"].width, 
							this.layouts[this.currentLayout]["elements"]["CheckEnable"].height);
							
		
			this.parent.appPanel.add(this.element_ADCReading.getZebraUIElement());
			
			this.parent.appPanel.add(this.element_ADCValue.getZebraUIElement());
			
			this.parent.appPanel.add(this.element_CheckEnable.getZebraUIElement());
			
			this.parent.appPanel.add(this.element_Slider14.getZebraUIElement());
			
			this.parent.appPanel.add(this.element_BtnClear.getZebraUIElement());
			
			this.parent.appPanel.add(this.element_Label19.getZebraUIElement());
			
	};

}
